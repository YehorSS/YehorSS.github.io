mod catalog;
mod classes;
#[cfg(windows)]
pub mod desktop;
mod gear;
mod planner;
mod tree;
mod ui;
#[cfg(target_arch = "wasm32")]
mod web_abi;
use catalog::Snapshot;
use planner::{Goal, Phase};
use std::{env, path::PathBuf, process::ExitCode};

pub const WEB_REQUEST_LIMIT: usize = 16 * 1024 * 1024;

pub fn process_web_request(input: &[u8]) -> String {
    use serde_json::json;
    if input.len() > WEB_REQUEST_LIMIT {
        return json!({"error": "Файл слишком большой для расчёта."}).to_string();
    }
    let request = match serde_json::from_slice::<ui::Request>(input) {
        Ok(request) => request,
        Err(_) => return json!({"error": "Параметры расчёта повреждены."}).to_string(),
    };
    match ui::execute(&request) {
        Ok(result) => json!({"id": request.id, "result": result}),
        Err(error) => json!({"id": request.id, "error": error}),
    }
    .to_string()
}

struct Options {
    goal: Goal,
    phase: Phase,
    style: String,
    skill: Option<String>,
    buttons: u8,
    level: usize,
    skill_tier: u8,
    spirit_tier: u8,
    support_tier: u8,
    spirit: u16,
    sockets: usize,
    top: usize,
    base_hit: f64,
    base_aps: f64,
    life: Option<f64>,
    data: Option<PathBuf>,
    inventory: Option<PathBuf>,
    tree: Option<PathBuf>,
    start: Option<String>,
    target: Option<String>,
    allocated: Vec<String>,
    points: usize,
}
impl Default for Options {
    fn default() -> Self {
        Self {
            goal: Goal::Damage,
            phase: Phase::Acts,
            style: "any".into(),
            skill: None,
            buttons: 1,
            level: 1,
            skill_tier: 1,
            spirit_tier: 1,
            support_tier: 1,
            spirit: 0,
            sockets: 2,
            top: 5,
            base_hit: 100.0,
            base_aps: 1.0,
            life: None,
            data: None,
            inventory: None,
            tree: None,
            start: None,
            target: None,
            allocated: vec![],
            points: 0,
        }
    }
}
const HELP: &str = "\
PoE 2 Build · проверяемые расчёты для друида
--phase acts|endgame    --goal damage|survival|clear|balanced
--style any|bear|wolf|caster    --skill Furious_Slam|Lunar_Assault|...
--buttons 1|2    --gem-level 1..20    --skill-tier 1..20
--spirit-tier 1..20    --support-tier 1..5    --sockets 0..5    --spirit 0..65535
--base-hit ЧИСЛО    --base-aps ЧИСЛО    --life HP    --top 1..50
--data JSON    --inventory JSON
--tree JSON --start ID --target ID --points N [--allocated ID,ID]
";
fn number<T>(flag: &str, value: &str, min: T, max: T) -> Result<T, String>
where
    T: std::str::FromStr + PartialOrd + std::fmt::Display,
{
    value
        .parse::<T>()
        .ok()
        .filter(|n| &min <= n && n <= &max)
        .ok_or_else(|| format!("{flag}: нужно число от {min} до {max}."))
}
fn parse(args: Vec<String>) -> Result<Options, String> {
    let mut o = Options::default();
    if !args.len().is_multiple_of(2) {
        return Err("После каждого параметра укажи значение.".into());
    }
    let pairs = args.as_chunks::<2>().0;
    if let Some(pair) = pairs.iter().rev().find(|pair| pair[0] == "--phase") {
        match pair[1].as_str() {
            "acts" => {}
            "endgame" => {
                o.phase = Phase::Endgame;
                o.level = 20;
                o.skill_tier = 20;
                o.spirit_tier = 20;
                o.support_tier = 5;
                o.sockets = 5;
            }
            _ => return Err("--phase: acts или endgame.".into()),
        }
    }
    for pair in pairs {
        let (f, v) = (pair[0].as_str(), pair[1].as_str());
        match f {
            "--phase" => {}
            "--goal" => {
                o.goal = match v {
                    "damage" => Goal::Damage,
                    "survival" => Goal::Survival,
                    "clear" => Goal::Clear,
                    "balanced" => Goal::Balanced,
                    _ => return Err(format!("Неизвестная цель «{v}».")),
                }
            }
            "--style" if matches!(v, "any" | "bear" | "wolf" | "caster") => o.style = v.into(),
            "--skill" => {
                let id = v.replace([' ', '-'], "_");
                if !catalog::ATTACKS
                    .iter()
                    .chain(catalog::SPELLS)
                    .any(|n| n.eq_ignore_ascii_case(&id))
                {
                    return Err(format!("Умения «{v}» нет в каталоге."));
                }
                o.skill = Some(id);
            }
            "--buttons" => o.buttons = number(f, v, 1, 2)?,
            "--gem-level" => o.level = number(f, v, 1, 20)?,
            "--skill-tier" => o.skill_tier = number(f, v, 1, 20)?,
            "--spirit-tier" => o.spirit_tier = number(f, v, 1, 20)?,
            "--support-tier" => o.support_tier = number(f, v, 1, 5)?,
            "--sockets" => o.sockets = number(f, v, 0, 5)?,
            "--spirit" => o.spirit = number(f, v, 0, u16::MAX)?,
            "--top" => o.top = number(f, v, 1, 50)?,
            "--base-hit" => o.base_hit = number(f, v, 0.001, 1_000_000.0)?,
            "--base-aps" => o.base_aps = number(f, v, 0.001, 100.0)?,
            "--life" => o.life = Some(number(f, v, 0.001, 1_000_000.0)?),
            "--data" => o.data = Some(v.into()),
            "--inventory" => o.inventory = Some(v.into()),
            "--tree" => o.tree = Some(v.into()),
            "--start" => o.start = Some(v.into()),
            "--target" => o.target = Some(v.into()),
            "--allocated" => {
                o.allocated = v
                    .split(',')
                    .map(str::trim)
                    .filter(|id| !id.is_empty())
                    .map(str::to_owned)
                    .collect()
            }
            "--points" => o.points = number(f, v, 0, 200)?,
            _ => return Err(format!("Неизвестный параметр «{f}».")),
        }
    }
    Ok(o)
}
fn run(o: &Options) -> Result<(), String> {
    if let Some(path) = &o.tree {
        return tree::print_route(path, o);
    }
    let data = Snapshot::load(o.data.as_deref())?;
    println!(
        "PoE 2 Build · {} · снимок PoE2DB от {}",
        match o.phase {
            Phase::Acts => "Акты",
            Phase::Endgame => "Эндгейм",
        },
        data.retrieved
    );
    if let Some(path) = &o.inventory {
        gear::run(path, &data, o)?;
    } else {
        if matches!(o.goal, Goal::Damage | Goal::Balanced) {
            planner::damage(&data, o);
        }
        if matches!(o.goal, Goal::Survival | Goal::Balanced) {
            planner::survival(&data, o);
        }
        if matches!(o.goal, Goal::Clear | Goal::Balanced) {
            planner::clear(&data, o);
        }
    }
    if matches!(o.style.as_str(), "any" | "bear") {
        planner::progression(o.phase);
    }
    Ok(())
}
pub fn run_cli() -> ExitCode {
    let args: Vec<_> = env::args().skip(1).collect();
    if args.iter().any(|s| s == "--help" || s == "-h") {
        print!("{HELP}");
        return ExitCode::SUCCESS;
    }
    match parse(args).and_then(|o| run(&o)) {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("{error} Справка — --help.");
            ExitCode::from(2)
        }
    }
}
