use crate::{
    catalog::{name, Snapshot, ACTS_GUIDE, ATTACKS, SOURCE, SPELLS},
    Options,
};
use std::cmp::Ordering;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Goal {
    Damage,
    Survival,
    Clear,
    Balanced,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Phase {
    Acts,
    Endgame,
}

pub struct Attack {
    pub physical: f64,
    pub cold: f64,
    pub attacks_per_second: f64,
}

impl Attack {
    pub fn dps(&self) -> f64 {
        (self.physical + self.cold) * self.attacks_per_second
    }
}

pub fn attack(
    data: &Snapshot,
    id: &str,
    level: usize,
    hit: f64,
    aps: f64,
    supports: &[&str],
) -> Attack {
    let gem = &data.gems[id];
    let coefficient = gem.levels[level - 1].values[0] / 100.0;
    let mut physical = hit * coefficient * (1.0 - gem.cold / 100.0);
    let mut cold = hit * coefficient * gem.cold / 100.0;
    let mut increased_speed = 0.0;
    let mut less_speed = 1.0;
    for id in supports {
        let support = &data.supports[*id];
        if id.starts_with("Brutality") {
            physical *= 1.0 + support.value / 100.0;
            cold = 0.0;
        } else if id.starts_with("Rapid_Attacks") {
            increased_speed += support.value / 100.0;
        } else if *id == "Heavy_Swing" {
            physical *= 1.0 + support.value / 100.0;
            less_speed *= 1.0 - support.secondary / 100.0;
        }
    }
    Attack {
        physical,
        cold,
        attacks_per_second: aps * gem.speed / 100.0 * (1.0 + increased_speed) * less_speed,
    }
}

pub fn best_attack(
    data: &Snapshot,
    id: &str,
    options: &Options,
    hit: f64,
    aps: f64,
) -> (Attack, Vec<&'static str>) {
    let groups: &[&[&str]] = match id {
        "Furious_Slam" => &[
            &["Brutality_I", "Brutality_II"],
            &["Rapid_Attacks_I", "Rapid_Attacks_II"],
            &["Heavy_Swing"],
        ],
        "Lunar_Assault" => &[&["Rapid_Attacks_I", "Rapid_Attacks_II"]],
        _ => &[],
    };
    let mut choices = vec![Vec::new()];
    for group in groups {
        let additions: Vec<_> = choices
            .iter()
            .filter(|choice| choice.len() < options.sockets)
            .flat_map(|choice| {
                group
                    .iter()
                    .filter(|&&id| data.supports[id].tier <= options.support_tier)
                    .map(move |&id| {
                        let mut chosen = choice.clone();
                        chosen.push(id);
                        chosen
                    })
            })
            .collect();
        choices.extend(additions);
    }
    choices
        .into_iter()
        .map(|supports| {
            (
                attack(data, id, options.level, hit, aps, &supports),
                supports,
            )
        })
        .max_by(|(a, sa), (b, sb)| {
            a.dps()
                .total_cmp(&b.dps())
                .then_with(|| sb.len().cmp(&sa.len()))
        })
        .expect("the empty set is always available")
}

pub fn gem_allowed(data: &Snapshot, options: &Options, id: &str) -> bool {
    let style_ok = match options.style.as_str() {
        "any" => true,
        "bear" => matches!(id, "Furious_Slam" | "Rampage"),
        "wolf" => id == "Lunar_Assault",
        "caster" => SPELLS.contains(&id),
        _ => false,
    };
    style_ok
        && data.gems[id].tier <= options.skill_tier
        && options
            .skill
            .as_deref()
            .is_none_or(|wanted| id.eq_ignore_ascii_case(wanted))
}

pub fn helper(
    data: &Snapshot,
    options: &Options,
    id: &str,
) -> Option<(&'static str, &'static str)> {
    if options.buttons < 2 {
        return None;
    }
    let (helper, note) = match id {
        "Furious_Slam" | "Rampage" => ("Ferocious_Roar", "генерация ярости рядом с врагами"),
        "Lunar_Assault" => ("Arctic_Howl", "условное усиление холодом при заморозке"),
        "Volcano" => (
            "Furious_Slam",
            "удар Slam по вулкану вызывает дополнительные выбросы; нужен талисман",
        ),
        "Entangle" => ("Thunderstorm", "дождь разращивает лозы"),
        "Thunderstorm" => ("Entangle", "лозы, которые разращивает дождь"),
        _ => return None,
    };
    (data.gems[helper].tier <= options.skill_tier).then_some((helper, note))
}

fn print_helper(data: &Snapshot, options: &Options, id: &str) {
    if let Some((helper, note)) = helper(data, options, id) {
        println!("  Вторая кнопка, вариант связки — {} ({note}). В расчёт урона не включена. {SOURCE}{helper}", name(helper));
    }
}

pub fn damage(data: &Snapshot, options: &Options) {
    println!("Модель атаки: одна базовая волна/попадание за атаку, стоя в своей форме.");
    println!(
        "Исходная база: {:.2} физ. урона за удар × {:.2} атак/с.",
        options.base_hit, options.base_aps
    );
    println!("Формула: (физ. часть после модов + холод после модов) × базовая скорость × скорость камня × (1 + increased) × less.");
    println!("Урон до защиты, без критов, промахов, ярости, дополнительных волн и пауз.");
    let mut ranked: Vec<_> = ATTACKS
        .iter()
        .copied()
        .filter(|&id| id != "Rampage" && gem_allowed(data, options, id))
        .map(|id| {
            (
                id,
                best_attack(data, id, options, options.base_hit, options.base_aps),
            )
        })
        .collect();
    ranked.sort_by(|a, b| {
        b.1 .0
            .dps()
            .partial_cmp(&a.1 .0.dps())
            .unwrap_or(Ordering::Equal)
            .then_with(|| a.0.cmp(b.0))
    });
    for (id, (result, supports)) in ranked.into_iter().take(options.top) {
        let gem = &data.gems[id];
        let row = &gem.levels[options.level - 1];
        println!(
            "\n{} — {:.3} урона/с в модели ({:.3} физ. + {:.3} холод) × {:.3} атак/с.",
            name(id),
            result.dps(),
            result.physical,
            result.cold,
            result.attacks_per_second
        );
        println!("  Уровень камня {} (требуется уровень персонажа {}), множитель урона {}%, скорости {}%, конверсия в холод {}%. {SOURCE}{id}",
            options.level, row.requires, row.values[0], gem.speed, gem.cold);
        for support_id in supports {
            let s = &data.supports[support_id];
            let effect = if support_id.starts_with("Brutality") {
                format!(
                    "{}% more физического, стихийный и хаос-урон отключены",
                    s.value
                )
            } else if support_id == "Heavy_Swing" {
                format!(
                    "{}% more физического ближнего, {}% less скорости",
                    s.value, s.secondary
                )
            } else {
                format!("{}% increased скорости атаки", s.value)
            };
            println!("  + {} — {effect}. {SOURCE}{support_id}", name(support_id));
        }
        print_helper(data, options, id);
    }
    for id in ["Rampage"]
        .into_iter()
        .chain(SPELLS.iter().copied())
        .filter(|&id| gem_allowed(data, options, id))
    {
        let row = &data.gems[id].levels[options.level - 1];
        if id == "Rampage" {
            println!("\nRampage — {}% базового урона за попадание. DPS канала зависит от ярости, движения и попаданий. {SOURCE}{id}", row.values[0]);
        } else {
            println!("\n{} — {}–{} базового урона одного попадания ({}) на уровне {}; полный DPS зависит от частоты реальных попаданий. {SOURCE}{id}",
                name(id), row.values[0], row.values[1], match id { "Volcano" => "выброс", "Entangle" => "трещина", _ => "молния" }, options.level);
        }
        print_helper(data, options, id);
    }
}

pub struct Recovery {
    pub interval: f64,
    pub heal: f64,
    pub spirit: u16,
    pub support: Option<&'static str>,
}

pub fn recovery(data: &Snapshot, options: &Options) -> Option<Recovery> {
    let gem = &data.gems["Time_of_Need"];
    if gem.tier > options.spirit_tier || gem.spirit > options.spirit {
        return None;
    }
    let row = &gem.levels[options.level - 1];
    let (interval, heal) = (row.values[0], row.values[1]);
    let support = ["Vitality_II", "Vitality_I"]
        .into_iter()
        .filter(|id| {
            let s = &data.supports[*id];
            options.sockets > 0
                && s.tier <= options.support_tier
                && u32::from(gem.spirit) + u32::from(s.spirit) <= u32::from(options.spirit)
        })
        .max_by(|a, b| data.supports[*a].value.total_cmp(&data.supports[*b].value));
    let spirit = gem.spirit + support.map_or(0, |id| data.supports[id].spirit);
    Some(Recovery {
        interval,
        heal,
        spirit,
        support,
    })
}

pub fn survival(data: &Snapshot, options: &Options) {
    println!("Живучесть — средний потенциал восстановления при постоянной нехватке HP.");
    let Some(Recovery {
        interval,
        heal,
        spirit,
        support,
    }) = recovery(data, options)
    else {
        let gem = &data.gems["Time_of_Need"];
        println!("Time of Need требует камень Духа тира {} и {} Духа. Для текущего бюджета измеряемой связки в каталоге нет.", gem.tier, gem.spirit);
        return;
    };
    println!(
        "Time of Need: {heal} HP раз в {interval} с, {:.3} HP/с в среднем. {SOURCE}Time_of_Need",
        heal / interval
    );
    if let Some(id) = support {
        let s = &data.supports[id];
        println!(
            "+ {}: {}% максимального здоровья/с, всего {} Духа. {SOURCE}{id}",
            name(id),
            s.value,
            spirit
        );
        if let Some(life) = options.life {
            println!(
                "Восстановление = {heal}/{interval} + {life}×{}/100 = {:.3} HP/с.",
                s.value,
                heal / interval + life * s.value / 100.0
            );
        }
    } else {
        println!("Резерв — {spirit} Духа.");
    }
    println!("Снятие состояний, входящий урон, время между благословениями и риск ваншота требуют отдельной оценки.");
}

pub fn area_support(data: &Snapshot, options: &Options) -> Option<&'static str> {
    ["Magnified_Area_II", "Magnified_Area_I"]
        .into_iter()
        .filter(|id| options.sockets > 0 && data.supports[*id].tier <= options.support_tier)
        .max_by(|a, b| data.supports[*a].value.total_cmp(&data.supports[*b].value))
}

pub fn clear(data: &Snapshot, options: &Options) {
    println!("Зачистка — бонус площади отдельного умения. Скорость зачистки зависит также от геометрии, попаданий и карты.");
    let support = area_support(data, options);
    for id in ["Furious_Slam", "Lunar_Assault", "Thunderstorm", "Rampage"]
        .into_iter()
        .filter(|&id| gem_allowed(data, options, id))
        .take(options.top)
    {
        match support {
            Some(s) => println!(
                "{} + {} → ×{:.2} площади при нулевом исходном increased AoE. {SOURCE}{s}",
                name(id),
                name(s),
                1.0 + data.supports[s].value / 100.0
            ),
            None => println!("{} → ×1.00 площади. {SOURCE}{id}", name(id)),
        }
    }
}

pub fn progression(phase: Phase) {
    println!("\nМаршрут для медведя (гайд Meteor Bear Shaman, 0.5):");
    match phase {
        Phase::Acts => println!("  В разделе Passive Tree выбери Act 1 → Act 2 → Act 3 → Act 4 → Interludes. Сравнивай дерево с текущим этапом."),
        Phase::Endgame => println!("  В разделе Passive Tree выбери Early Maps → Red Maps → Endgame. У гайда есть требования к экипировке для поздних вариантов."),
    }
    println!("  {ACTS_GUIDE}");
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn verified_furious_slam_formula() {
        let data = Snapshot::load(None).unwrap();
        let result = attack(
            &data,
            "Furious_Slam",
            1,
            100.0,
            1.0,
            &["Brutality_I", "Rapid_Attacks_I"],
        );
        assert!((result.dps() - 70.4375).abs() < 1e-9);
    }

    #[test]
    fn conversion_retains_only_the_destination_type() {
        let data = Snapshot::load(None).unwrap();
        let result = attack(&data, "Lunar_Assault", 1, 100.0, 1.0, &["Brutality_I"]);
        assert!((result.physical - 10.0).abs() < 1e-9);
        assert_eq!(result.cold, 0.0);
    }

    #[test]
    fn shared_family_and_available_sockets_are_enforced() {
        let data = Snapshot::load(None).unwrap();
        let options = Options {
            support_tier: 4,
            sockets: 2,
            ..Options::default()
        };
        let (_, supports) = best_attack(&data, "Furious_Slam", &options, 100.0, 1.0);
        assert_eq!(supports.len(), 2);
        assert!(supports.contains(&"Brutality_II"));
        assert!(supports.contains(&"Rapid_Attacks_II"));
    }
}
