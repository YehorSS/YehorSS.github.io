use crate::Options;
use serde::Deserialize;
use serde::Serialize;
use std::{
    collections::{BTreeMap, BTreeSet, VecDeque},
    fs,
    path::Path,
};

#[derive(Deserialize)]
struct Graph {
    nodes: BTreeMap<String, Node>,
}

#[derive(Deserialize)]
#[serde(untagged)]
enum LinkId {
    Number(u32),
    Text(String),
}

impl LinkId {
    fn key(&self) -> String {
        match self {
            Self::Number(id) => id.to_string(),
            Self::Text(id) => id.clone(),
        }
    }
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct Node {
    #[serde(default)]
    name: String,
    #[serde(default)]
    stats: Vec<String>,
    #[serde(default, rename = "in")]
    incoming: Vec<LinkId>,
    #[serde(default, rename = "out")]
    outgoing: Vec<LinkId>,
    class_start_index: Option<serde_json::Value>,
    ascendancy_name: Option<String>,
    #[serde(default)]
    is_ascendancy_start: bool,
    #[serde(default)]
    is_proxy: bool,
    #[serde(default)]
    is_jewel_socket: bool,
    #[serde(default)]
    is_mastery: bool,
    #[serde(default)]
    is_multiple_choice: bool,
    #[serde(default)]
    is_multiple_choice_option: bool,
    #[serde(default)]
    is_free_allocate: bool,
}
impl Node {
    fn regular(&self) -> bool {
        self.class_start_index.is_none()
            && self.ascendancy_name.as_deref().is_none_or(str::is_empty)
            && !self.is_ascendancy_start
            && !self.is_proxy
            && !self.is_jewel_socket
            && !self.is_mastery
            && !self.is_multiple_choice
            && !self.is_multiple_choice_option
            && !self.is_free_allocate
            && !self.name.is_empty()
    }
}

fn edges(graph: &Graph, start: &str) -> BTreeMap<String, BTreeSet<String>> {
    let mut result = BTreeMap::<String, BTreeSet<String>>::new();
    let ascendancy = graph.nodes.get(start).and_then(|node| {
        node.is_ascendancy_start
            .then_some(node.ascendancy_name.as_deref())
            .flatten()
    });
    let allowed = |node: &Node| match ascendancy {
        Some(name) => {
            node.ascendancy_name.as_deref() == Some(name)
                && !node.is_ascendancy_start
                && !node.is_proxy
                && !node.is_jewel_socket
                && !node.is_multiple_choice_option
                && !node.is_multiple_choice
                && !node.is_free_allocate
                && !node.is_mastery
                && !node.name.is_empty()
        }
        None => node.regular(),
    };
    for (id, node) in &graph.nodes {
        if id != start && !allowed(node) {
            continue;
        }
        result.entry(id.clone()).or_default();
        for peer in node.incoming.iter().chain(&node.outgoing).map(LinkId::key) {
            if peer == start || graph.nodes.get(&peer).is_some_and(allowed) {
                result.entry(id.clone()).or_default().insert(peer.clone());
                result.entry(peer).or_default().insert(id.clone());
            }
        }
    }
    result
}

fn route(
    graph: &Graph,
    start: &str,
    target: &str,
    allocated: &[String],
) -> Result<Vec<String>, String> {
    if !graph.nodes.get(start).is_some_and(|n| {
        n.class_start_index.is_some()
            || (n.is_ascendancy_start
                && n.ascendancy_name.as_deref().is_some_and(|s| !s.is_empty()))
    }) {
        return Err("Старт должен быть узлом класса из дерева.".into());
    }
    let edges = edges(graph, start);
    if !edges.contains_key(target) {
        return Err("Цель должна быть обычным узлом пассивного дерева.".into());
    }
    let mut existing = BTreeSet::from([start.to_owned()]);
    existing.extend(allocated.iter().cloned());
    let mut connected = BTreeSet::from([start.to_owned()]);
    let mut queue = VecDeque::from([start.to_owned()]);
    while let Some(id) = queue.pop_front() {
        for peer in &edges[&id] {
            if existing.contains(peer) && connected.insert(peer.clone()) {
                queue.push_back(peer.clone());
            }
        }
    }
    if connected != existing {
        return Err("Уже взятые узлы должны образовывать связную ветку от старта.".into());
    }
    let mut parent: BTreeMap<String, Option<String>> =
        connected.into_iter().map(|id| (id, None)).collect();
    let mut queue: VecDeque<_> = parent.keys().cloned().collect();
    while let Some(id) = queue.pop_front() {
        if id == target {
            let mut path = Vec::new();
            let mut step = id;
            while let Some(previous) = &parent[&step] {
                path.push(step.clone());
                step = previous.clone();
            }
            path.reverse();
            return Ok(path);
        }
        for peer in &edges[&id] {
            if !parent.contains_key(peer) {
                parent.insert(peer.clone(), Some(id.clone()));
                queue.push_back(peer.clone());
            }
        }
    }
    Err("Пути по обычным узлам до цели нет.".into())
}

#[derive(Serialize)]
pub struct Start {
    id: String,
    name: String,
    index: serde_json::Value,
}

#[derive(Serialize)]
pub struct Step {
    id: String,
    name: String,
    stats: Vec<String>,
    available: bool,
}

#[derive(Serialize)]
pub struct Route {
    target: String,
    points: usize,
    steps: Vec<Step>,
}

#[derive(Serialize)]
#[serde(tag = "view", rename_all = "snake_case")]
pub enum TreeReport {
    Starts { starts: Vec<Start> },
    Route { route: Route },
}

pub fn report(json: &str, o: &Options) -> Result<TreeReport, String> {
    report_scope(json, o, None)
}

pub fn report_scope(
    json: &str,
    o: &Options,
    ascendancy: Option<&str>,
) -> Result<TreeReport, String> {
    let graph: Graph =
        serde_json::from_str(json.trim_start_matches('\u{feff}')).map_err(|err| err.to_string())?;
    let Some(start) = o.start.as_deref() else {
        let starts = graph
            .nodes
            .iter()
            .filter_map(|(id, node)| match ascendancy {
                Some(wanted)
                    if node.is_ascendancy_start
                        && node.ascendancy_name.as_deref().is_some_and(|name| {
                            name.eq_ignore_ascii_case(wanted)
                                || node.name.eq_ignore_ascii_case(wanted)
                        }) =>
                {
                    Some(Start {
                        id: id.clone(),
                        name: wanted.to_owned(),
                        index: serde_json::Value::Null,
                    })
                }
                Some(_) => None,
                None => node.class_start_index.clone().map(|index| Start {
                    id: id.clone(),
                    name: node.name.clone(),
                    index,
                }),
            })
            .collect();
        return Ok(TreeReport::Starts { starts });
    };
    let requested = o
        .target
        .as_deref()
        .ok_or("Укажи --target ID или точное имя узла.")?;
    let target = if graph.nodes.contains_key(requested) {
        requested
    } else {
        let allowed = edges(&graph, start);
        let mut matches = graph
            .nodes
            .iter()
            .filter(|(id, node)| {
                allowed.contains_key(*id) && node.name.eq_ignore_ascii_case(requested)
            })
            .map(|(id, _)| id.as_str());
        let unique = matches.next().ok_or("Целевой узел не найден.")?;
        if matches.next().is_some() {
            return Err("У нескольких узлов это имя. Укажи ID цели.".into());
        }
        unique
    };
    let steps = route(&graph, start, target, &o.allocated)?
        .into_iter()
        .enumerate()
        .map(|(i, id)| {
            let n = &graph.nodes[&id];
            Step {
                id,
                name: n.name.clone(),
                stats: n.stats.clone(),
                available: i < o.points,
            }
        })
        .collect();
    Ok(TreeReport::Route {
        route: Route {
            target: graph.nodes[target].name.clone(),
            points: o.points,
            steps,
        },
    })
}

pub fn print_route(path: &Path, o: &Options) -> Result<(), String> {
    let json = fs::read_to_string(path).map_err(|err| err.to_string())?;
    match report(&json, o)? {
        TreeReport::Starts { starts } => {
            println!("Стартовые узлы файла. Укажи ID своего класса через --start.");
            for start in starts {
                println!(
                    "{} — {} (индекс класса {})",
                    start.id, start.name, start.index
                );
            }
        }
        TreeReport::Route { route } => {
            println!(
                "Кратчайший путь к {}. Нужно {} новых очков, доступно {}.",
                route.target,
                route.steps.len(),
                route.points
            );
            for (i, step) in route.steps.into_iter().enumerate() {
                let status = if step.available {
                    "сейчас"
                } else {
                    "позже"
                };
                println!(
                    "{}. {} [{}] — {}. {}",
                    i + 1,
                    step.name,
                    step.id,
                    status,
                    step.stats.join(" / ")
                );
            }
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn shortest_route_avoids_other_class_start_and_uses_existing_nodes() {
        let graph: Graph = serde_json::from_str(r#"{"nodes":{"1":{"name":"Druid","classStartIndex":4,"out":["2","9"]},"2":{"name":"Small","out":["3"]},"3":{"name":"Small","out":["4"]},"4":{"name":"Target"},"9":{"name":"Other","classStartIndex":3,"out":["4"]}}}"#).unwrap();
        assert_eq!(route(&graph, "1", "4", &["2".into()]).unwrap(), ["3", "4"]);
        assert!(route(&graph, "1", "4", &["4".into()]).is_err());
    }

    #[test]
    fn ascendancy_route_never_uses_the_main_tree_or_another_ascendancy() {
        let graph: Graph = serde_json::from_str(r#"{"nodes":{
            "1":{"name":"Infernalist","isAscendancyStart":true,"ascendancyName":"Infernalist","out":[2,5,6]},
            "2":{"name":"Minion Life","ascendancyName":"Infernalist","out":[3]},
            "3":{"name":"Loyal Hellhound","ascendancyName":"Infernalist"},
            "5":{"name":"Lich","isAscendancyStart":true,"ascendancyName":"Lich","out":[3]},
            "6":{"name":"Main Tree","out":[3]}}}"#).unwrap();
        assert_eq!(route(&graph, "1", "3", &[]).unwrap(), ["2", "3"]);
        assert!(route(&graph, "1", "5", &[]).is_err());
    }
}
