use crate::{
    catalog::{self, name, Snapshot, SOURCE},
    classes, gear, parse,
    planner::{self, Goal},
    tree,
};
use serde::Deserialize;
use serde_json::{json, Value};
use std::collections::BTreeMap;

const MINION_GUIDE: &str =
    "https://mobalytics.gg/poe-2/builds/thyworm-infernalist-leveling#passive-tree";

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Request {
    pub id: u64,
    pub action: String,
    #[serde(default)]
    params: BTreeMap<String, String>,
    #[serde(default)]
    pub input: String,
}

#[derive(Deserialize)]
struct Minion {
    tier: u8,
    levels: Vec<[u16; 3]>,
}

pub fn execute(req: &Request) -> Result<Value, String> {
    if req.action == "classes" {
        return Ok(json!({ "classes": classes::CLASSES }));
    }
    if req.action == "characters" {
        return classes::roster(&req.input);
    }
    let mut args = Vec::new();
    for (key, value) in &req.params {
        if matches!(
            key.as_str(),
            "phase"
                | "goal"
                | "style"
                | "buttons"
                | "gem-level"
                | "skill-tier"
                | "spirit-tier"
                | "support-tier"
                | "spirit"
                | "sockets"
                | "base-hit"
                | "base-aps"
                | "life"
                | "top"
                | "start"
                | "target"
                | "points"
                | "allocated"
        ) && !value.trim().is_empty()
        {
            args.extend([format!("--{key}"), value.trim().to_owned()]);
        }
    }
    let options = parse(args)?;
    let style = req.params.get("playstyle").map_or("bear", String::as_str);
    let character = req.params.get("character").map_or("auto", String::as_str);
    let class_profile = classes::select_class(character, style);
    let class = class_profile.id;
    let hero_level = optional_number(req, "character-level")?.map(|value| value as u16);
    let (picks, guide) = match (class, style) {
        ("witch", "minion") => (vec![
            ascend("Infernalist", "Loyal Hellhound", "Открывает Summon Infernal Hound. Beidat’s Will добавляет 1 Дух за 25 максимума HP и резервирует 25% жизни."),
            ascend("Lich", "Necromantic Conduit", "Даёт Unholy Might союзникам в присутствии, пока ты не на низкой мане. Расходует 5% максимума маны в секунду."),
        ], Some(MINION_GUIDE)),
        ("witch", "caster") => (vec![ascend("Blood_Mage", "Sunder the Flesh", "Путь для критических заклинаний. Узел устанавливает базовый шанс крита заклинаний в 15%.")], None),
        ("druid", "bear" | "wolf") => (vec![ascend("Shaman", "Furious Wellspring", "Путь через ярость. Узел даёт её регенерацию и повышает расход ярости умений.")], (style == "bear").then_some(catalog::ACTS_GUIDE)),
        ("druid", "caster") => (vec![ascend("Shaman", "", "Каждые 2 ярости также дают 1% more урона заклинаниями."), ascend("Oracle", "", "Есть ветки для критических заклинаний и тотемов.")], None),
        _ => (vec![], None),
    };
    let selected = req
        .params
        .get("ascendancy")
        .filter(|name| class_profile.ascendancies.contains(&name.as_str()));
    let mut picks = picks;
    if let Some(selected) = selected {
        picks.sort_by_key(|pick| pick["name"].as_str() != Some(selected));
    }
    let profile = json!({"class":class_profile.name,"class_id":class,"english":class_profile.english,"picks":picks,
       "guide":guide,"ascendancies":class_profile.ascendancies,"selected":selected,"starter":{"name":name(class_profile.starter),
       "tier":class_profile.tier,"source":format!("{SOURCE}{}",class_profile.starter)}});
    if req.action == "tree" {
        let scope = req
            .params
            .get("ascendancy")
            .map(String::as_str)
            .filter(|s| !s.is_empty());
        let data = if req.input.is_empty() && req.params.get("demo").is_some_and(|v| v == "1") {
            include_str!("../examples/tree.example.json")
        } else {
            &req.input
        };
        return serde_json::to_value(tree::report_scope(data, &options, scope)?)
            .map_err(|e| e.to_string());
    }
    let data = Snapshot::load(None)?;
    if req.action == "gear" {
        if (style == "minion" || class != "druid") && options.goal != Goal::Survival {
            return Err(
                "Для вещей этого класса и стиля сейчас доступно сравнение максимума HP. Выбери «Живучесть»."
                    .into(),
            );
        }
        let input = if req.input.is_empty() {
            include_str!("../examples/inventory.example.json")
        } else {
            &req.input
        };
        return serde_json::to_value(gear::report(input, &data, &options)?)
            .map_err(|e| e.to_string());
    }
    if req.action != "gems" {
        return Err("Неизвестное действие.".into());
    }
    let mut cards = Vec::new();
    let mut notice = None;
    let class_model =
        matches!((class, style), ("druid", "bear" | "wolf" | "caster")) || style == "minion";
    if !class_model && options.goal != Goal::Survival {
        if options.goal == Goal::Damage && class_profile.tier <= u16::from(options.skill_tier) {
            if let Some(result) = starter_hit(
                class_profile.starter,
                options.level,
                options.base_hit,
                hero_level,
            )? {
                cards.push(result);
            }
        }
        let note = if options.goal == Goal::Clear {
            "Скорость зачистки этого стиля пока не рассчитана. Стартовое умение указано в профиле класса."
        } else if class_profile.tier > u16::from(options.skill_tier) {
            "Для стартового умения нужен камень более высокого тира. Проверь тир в параметрах."
        } else if class == "witch" {
            "Полный расчёт для Ведьмы доступен в режиме «Призыватель»."
        } else if cards.is_empty() {
            "Подбери уровень камня к уровню персонажа."
        } else {
            "Показано базовое попадание по таблице камня. Поддержки, защита цели и боевой DPS в расчёт не входят."
        };
        return Ok(
            json!({"cards":cards,"profile":profile,"notice":note,"snapshot":data.retrieved}),
        );
    }
    if style == "minion" {
        let extra = if class == "witch"
            && selected.is_none_or(|name| name == "Infernalist")
            && req.params.get("beidat").is_some_and(|v| v == "1")
        {
            let life = options
                .life
                .ok_or("Для Beidat’s Will укажи максимальное HP.")?;
            (life / 25.0).floor() as u32
        } else {
            0
        };
        let permanent = optional_number(req, "reserved")?;
        let level = optional_number(req, "character-level")?;
        let int = optional_number(req, "intelligence")?;
        let total = u32::from(options.spirit) + extra;
        let reserved = permanent.unwrap_or(0);
        if reserved > total {
            return Err(format!(
                "Другие резервы ({reserved}) превышают максимум Духа ({total})."
            ));
        }
        let budget = total - reserved;
        let minions: BTreeMap<String, Minion> =
            serde_json::from_str(include_str!("../data/minions.json"))
                .map_err(|e| e.to_string())?;
        for id in [
            "Skeletal_Sniper",
            "Skeletal_Arsonist",
            "Skeletal_Frost_Mage",
            "Skeletal_Storm_Mage",
        ] {
            let row = &minions[id];
            if row.tier > options.skill_tier {
                continue;
            }
            let [needs_level, needs_int, cost] = row.levels[options.level - 1];
            let unmet = level.is_some_and(|l| l < u32::from(needs_level))
                || int.is_some_and(|i| i < u32::from(needs_int));
            let cost = u32::from(cost);
            let reserve = if unmet { 0 } else { budget / cost };
            let note = if unmet {
                "Требования камня пока не выполнены."
            } else {
                "Максимум для одного вида миньонов при заданном бюджете."
            };
            let mut card = card(
                id,
                "Призывы",
                reserve as f64,
                "number",
                format!("⌊{budget} / {cost}⌋ = {}", budget / cost),
                vec![
                    ("Дух / миньон", cost as f64),
                    ("Нужен уровень", f64::from(needs_level)),
                    ("Нужен интеллект", f64::from(needs_int)),
                ],
                vec![],
                None,
                note,
            );
            if unmet {
                card["formula"] = json!(format!(
                    "{budget} Духа, стоимость {cost}. Проверь требования."
                ));
            }
            cards.push(card);
        }
        let breakdown = if extra > 0 || reserved > 0 {
            format!(
                " ({} база + {extra} Beidat’s Will − {reserved} в других резервах)",
                options.spirit
            )
        } else {
            String::new()
        };
        notice = Some(format!("Доступно {budget} Духа{breakdown}. Используется базовый резерв камня без качества и скидок."));
    } else if options.goal == Goal::Survival {
        if let Some(r) = planner::recovery(&data, &options) {
            let percent = r.support.map_or(0.0, |id| data.supports[id].value);
            let extra = options.life.unwrap_or_default() * percent / 100.0;
            let rate = r.heal / r.interval + extra;
            let formula = if let Some(life) = options.life {
                format!(
                    "{} ÷ {} + {life} × {percent}% = {rate:.3} HP/с",
                    r.heal, r.interval
                )
            } else {
                format!("{} ÷ {} = {rate:.3} HP/с", r.heal, r.interval)
            };
            let note = if percent > 0.0 && options.life.is_none() {
                "Укажи максимум HP, чтобы добавить регенерацию Vitality в расчёт."
            } else {
                "Среднее восстановление при постоянном дефиците здоровья."
            };
            cards.push(card(
                "Time_of_Need",
                "Восстановление",
                rate,
                "hp/s",
                formula,
                vec![
                    ("Здоровья за раз", r.heal),
                    ("Интервал, с", r.interval),
                    ("Резерв Духа", f64::from(r.spirit)),
                ],
                r.support.into_iter().collect(),
                None,
                note,
            ));
        } else {
            let gem = &data.gems["Time_of_Need"];
            notice = Some(format!(
                "Для Time of Need требуются тир камня Духа {} и {} Духа.",
                gem.tier, gem.spirit
            ));
        }
    } else if options.goal == Goal::Clear {
        for id in ["Furious_Slam", "Lunar_Assault", "Thunderstorm", "Rampage"]
            .into_iter()
            .filter(|id| planner::gem_allowed(&data, &options, id))
        {
            let support = planner::area_support(&data, &options);
            let bonus = support.map_or(0.0, |id| data.supports[id].value);
            let area = 1.0 + bonus / 100.0;
            cards.push(card(
                id,
                "Площадь",
                area,
                "×",
                format!("1 + {bonus} ÷ 100 = {area:.2}"),
                vec![("Бонус площади, %", bonus)],
                support.into_iter().collect(),
                planner::helper(&data, &options, id),
                "Множитель площади при нулевом исходном increased AoE.",
            ));
        }
    } else {
        for id in ["Furious_Slam", "Lunar_Assault"]
            .into_iter()
            .filter(|id| planner::gem_allowed(&data, &options, id))
        {
            let (result, supports) =
                planner::best_attack(&data, id, &options, options.base_hit, options.base_aps);
            cards.push(card(id, "Модельный урон", result.dps(), "DPS",
                format!("({:.3} + {:.3}) × {:.4} = {:.4}", result.physical, result.cold, result.attacks_per_second, result.dps()),
                vec![("Физ. за удар", result.physical), ("Холод за удар", result.cold), ("Атак/с", result.attacks_per_second)], supports,
                planner::helper(&data, &options, id), "Одно базовое попадание за атаку, уже в форме. Без защиты цели, критов, ярости и дополнительных волн."));
        }
        cards.sort_by(|a, b| {
            b["value"]
                .as_f64()
                .unwrap_or_default()
                .total_cmp(&a["value"].as_f64().unwrap_or_default())
        });
        for id in ["Rampage"]
            .into_iter()
            .chain(catalog::SPELLS.iter().copied())
            .filter(|id| planner::gem_allowed(&data, &options, id))
        {
            let row = &data.gems[id].levels[options.level - 1];
            let (label, value, unit, formula, stats) = if id == "Rampage" {
                (
                    "База за попадание",
                    row.values[0],
                    "%",
                    format!("Физическая база × {}%", row.values[0]),
                    vec![("Уровень камня", options.level as f64)],
                )
            } else {
                (
                    "Средний базовый удар",
                    (row.values[0] + row.values[1]) / 2.0,
                    "hit",
                    format!("({} + {}) ÷ 2", row.values[0], row.values[1]),
                    vec![("Мин. урон", row.values[0]), ("Макс. урон", row.values[1])],
                )
            };
            cards.push(card(
                id,
                label,
                value,
                unit,
                formula,
                stats,
                vec![],
                planner::helper(&data, &options, id),
                "Эффективное число попаданий зависит от боя. Полный DPS здесь не рассчитан.",
            ));
        }
    }
    cards.truncate(options.top);
    if style != "minion" {
        if let Some(level) = hero_level {
            cards.retain(|card| {
                card["id"]
                    .as_str()
                    .and_then(|id| data.gems.get(id))
                    .is_none_or(|gem| gem.levels[options.level - 1].requires <= level)
            });
            if cards.is_empty() && notice.is_none() {
                notice = Some(
                    "Уменьши уровень камня. Текущий уровень персонажа ниже требований.".into(),
                );
            }
        }
    }
    Ok(json!({"cards":cards, "profile":profile, "notice":notice, "snapshot": data.retrieved}))
}

fn optional_number(req: &Request, key: &str) -> Result<Option<u32>, String> {
    req.params
        .get(key)
        .filter(|s| !s.is_empty())
        .map(|s| {
            s.parse::<u32>()
                .ok()
                .filter(|n| *n <= 65535)
                .ok_or_else(|| format!("Проверь числовое поле {key}."))
        })
        .transpose()
}

fn starter_hit(
    id: &str,
    level: usize,
    hit: f64,
    hero_level: Option<u16>,
) -> Result<Option<Value>, String> {
    let table: BTreeMap<&str, Vec<Vec<u16>>> =
        serde_json::from_str(include_str!("../data/class-skills.json"))
            .map_err(|err| err.to_string())?;
    let Some(row) = table.get(id).and_then(|rows| rows.get(level - 1)) else {
        return Ok(None);
    };
    if hero_level.is_some_and(|level| level < row[0]) {
        return Ok(None);
    }
    let (value, formula, stats) = if id == "Spark" {
        let (lo, hi) = (row[1], row[2]);
        (
            f64::from(lo + hi) / 2.0,
            format!("({lo} + {hi}) ÷ 2"),
            vec![("Минимум", f64::from(lo)), ("Максимум", f64::from(hi))],
        )
    } else {
        let mut stats = vec![("Основной коэффициент, %", f64::from(row[1]))];
        if let Some(second) = row.get(2) {
            stats.push(("Второй коэффициент, %", f64::from(*second)));
        }
        (
            hit * f64::from(row[1]) / 100.0,
            format!("{hit} × {}%", row[1]),
            stats,
        )
    };
    Ok(Some(card(id, "База за попадание", value, "hit", formula, stats, vec![], None,
        "Расчёт для одного основного попадания до защиты цели. Второй коэффициент, если есть, показан отдельно.")))
}

fn ascend(id: &str, target: &str, description: &str) -> Value {
    json!({"name":name(id),"target":target,"source":format!("{SOURCE}{id}"),"description":description})
}

#[allow(clippy::too_many_arguments)]
fn card(
    id: &str,
    label: &str,
    value: f64,
    unit: &str,
    formula: String,
    stats: Vec<(&str, f64)>,
    support: Vec<&str>,
    helper: Option<(&str, &str)>,
    note: &str,
) -> Value {
    let support: Vec<_> = support
        .into_iter()
        .map(|id| json!({"name":name(id),"source":format!("{SOURCE}{id}")}))
        .collect();
    json!({"id":id,"name":name(id),"source":format!("{SOURCE}{id}"),"label":label,"value":value,"unit":unit,"formula":formula,
        "stats":stats,"supports":support,"helper":helper.map(|(id,note)|json!({"name":name(id),"note":note,"source":format!("{SOURCE}{id}")})), "note":note})
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn infernalist_rounds_spirit_and_checks_minion_requirement() {
        let r: Request = serde_json::from_value(json!({
            "id":1,"action":"gems","params":{"playstyle":"minion","gem-level":"20","skill-tier":"5","spirit":"100","life":"2500","beidat":"1","reserved":"21","character-level":"90","intelligence":"157"}
        })).unwrap();
        let v = execute(&r).unwrap();
        assert_eq!(v["cards"][0]["value"], 5.0);
        assert_eq!(v["profile"]["class"], "Ведьма");
        assert_eq!(v["profile"]["picks"][0]["name"], "Infernalist");
    }
}
