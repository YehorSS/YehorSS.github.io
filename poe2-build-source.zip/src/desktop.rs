use crate::ui::{self, Request};
use serde_json::json;
use std::{borrow::Cow, path::PathBuf};
use tao::{
    dpi::LogicalSize,
    event::{Event, WindowEvent},
    event_loop::{ControlFlow, EventLoopBuilder},
    window::WindowBuilder,
};
use wry::{
    http::{header::CONTENT_TYPE, Response, Uri},
    WebContext, WebViewBuilder,
};

pub fn run() -> Result<(), Box<dyn std::error::Error>> {
    let event_loop = EventLoopBuilder::<String>::with_user_event().build();
    let proxy = event_loop.create_proxy();
    let window = WindowBuilder::new()
        .with_title("PoE 2 Build — планировщик")
        .with_inner_size(LogicalSize::new(1420, 940))
        .with_min_inner_size(LogicalSize::new(780, 620))
        .build(&event_loop)?;
    let storage = std::env::var_os("LOCALAPPDATA")
        .map(PathBuf::from)
        .unwrap_or_else(std::env::temp_dir)
        .join("PoE2Build")
        .join("WebView2");
    let mut context = WebContext::new(Some(storage));
    let view = WebViewBuilder::new_with_web_context(&mut context)
        .with_background_color((23, 25, 25, 255))
        .with_custom_protocol("poe".into(), |_, request| {
            let (body, mime): (&'static [u8], &str) = match request.uri().path() {
                "/" | "/index.html" => (
                    include_bytes!("../ui/index.html"),
                    "text/html; charset=utf-8",
                ),
                "/style.css" => (include_bytes!("../ui/style.css"), "text/css; charset=utf-8"),
                "/app.js" => (
                    include_bytes!("../ui/app.js"),
                    "text/javascript; charset=utf-8",
                ),
                "/hero.jpg" => (include_bytes!("../ui/hero.jpg"), "image/jpeg"),
                "/witch.jpg" => (include_bytes!("../ui/witch.jpg"), "image/jpeg"),
                _ => {
                    return Response::builder()
                        .status(404)
                        .body(Cow::Borrowed(&[] as &[u8]))
                        .unwrap()
                }
            };
            Response::builder()
                .header(CONTENT_TYPE, mime)
                .body(Cow::Borrowed(body))
                .unwrap()
        })
        .with_url("poe://localhost")
        .with_navigation_handler(|url| {
            url.starts_with("http://poe.localhost/")
                || url == "http://poe.localhost"
                || url.starts_with("poe://localhost/")
                || url == "poe://localhost"
        })
        .with_ipc_handler(move |message| {
            if message.body().len() > 16 * 1024 * 1024 {
                return;
            }
            let Ok(req) = serde_json::from_str::<Request>(message.body()) else {
                return;
            };
            let proxy = proxy.clone();
            std::thread::spawn(move || {
                let result = if req.action == "open" {
                    let href = req.input.as_str();
                    if let Ok(uri) = href.parse::<Uri>() {
                        if uri.scheme_str() == Some("https")
                            && matches!(
                                uri.host(),
                                Some(
                                    "poe2db.tw"
                                        | "mobalytics.gg"
                                        | "github.com"
                                        | "www.pathofexile.com"
                                )
                            )
                        {
                            let _ = open::that(href);
                        }
                    }
                    Ok(serde_json::Value::Null)
                } else {
                    ui::execute(&req)
                };
                let reply = match result {
                    Ok(result) => json!({"id":req.id,"result":result}),
                    Err(error) => json!({"id":req.id,"error":error}),
                };
                let _ = proxy.send_event(reply.to_string());
            });
        })
        .build(&window)?;

    event_loop.run(move |event, _, control_flow| {
        let _keep_window = &window;
        *control_flow = ControlFlow::Wait;
        match event {
            Event::WindowEvent {
                event: WindowEvent::CloseRequested,
                ..
            } => *control_flow = ControlFlow::Exit,
            Event::UserEvent(data) => {
                let _ = view.evaluate_script(&format!("window.receiveBuildReply({data});"));
            }
            _ => {}
        }
    });
}

pub fn show_error(error: &str) {
    use windows_sys::Win32::UI::WindowsAndMessaging::{MessageBoxW, MB_ICONERROR, MB_OK};
    let body: Vec<u16> =
        format!("{error}\n\nПроверь, установлен ли Microsoft Edge WebView2 Runtime.")
            .encode_utf16()
            .chain([0])
            .collect();
    let title: Vec<u16> = "PoE 2 Build".encode_utf16().chain([0]).collect();
    // Both UTF-16 buffers remain valid through the synchronous call.
    unsafe {
        MessageBoxW(
            std::ptr::null_mut(),
            body.as_ptr(),
            title.as_ptr(),
            MB_ICONERROR | MB_OK,
        );
    }
}
