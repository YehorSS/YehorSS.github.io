fn main() -> std::process::ExitCode {
    poe2_build::run_cli()
}
