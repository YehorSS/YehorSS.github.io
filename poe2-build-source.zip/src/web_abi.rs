//! JSON boundary for the browser worker. The worker owns this instance.
use std::cell::RefCell;

thread_local! {
    static INPUT: RefCell<Vec<u8>> = const { RefCell::new(Vec::new()) };
    static OUTPUT: RefCell<Vec<u8>> = const { RefCell::new(Vec::new()) };
}

#[no_mangle]
pub extern "C" fn prepare_request(len: u32) -> u32 {
    if len == 0 || len as usize > crate::WEB_REQUEST_LIMIT {
        return 0;
    }
    INPUT.with(|input| {
        let mut input = input.borrow_mut();
        input.resize(len as usize, 0);
        input.as_mut_ptr() as u32
    })
}

#[no_mangle]
pub extern "C" fn process_request() {
    let result = INPUT.with(|input| crate::process_web_request(&input.borrow()));
    OUTPUT.with(|output| *output.borrow_mut() = result.into_bytes());
}

#[no_mangle]
pub extern "C" fn response_ptr() -> u32 {
    OUTPUT.with(|output| output.borrow().as_ptr() as u32)
}

#[no_mangle]
pub extern "C" fn response_len() -> u32 {
    OUTPUT.with(|output| output.borrow().len() as u32)
}
