use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

#[derive(Serialize)]
pub struct ClassProfile {
    pub id: &'static str,
    pub name: &'static str,
    pub english: &'static str,
    pub style: &'static str,
    pub styles: &'static [&'static str],
    pub starter: &'static str,
    pub tier: u16,
    pub ascendancies: &'static [&'static str],
}

pub const CLASSES: &[ClassProfile] = &[
    ClassProfile {
        id: "druid",
        name: "Друид",
        english: "Druid",
        style: "bear",
        styles: &["bear", "wolf", "caster"],
        starter: "Furious_Slam",
        tier: 1,
        ascendancies: &["Shaman", "Oracle"],
    },
    ClassProfile {
        id: "witch",
        name: "Ведьма",
        english: "Witch",
        style: "minion",
        styles: &["minion", "caster"],
        starter: "Skeletal_Sniper",
        tier: 1,
        ascendancies: &["Infernalist", "Lich", "Blood Mage"],
    },
    ClassProfile {
        id: "ranger",
        name: "Охотница с луком",
        english: "Ranger",
        style: "bow",
        styles: &["bow"],
        starter: "Lightning_Arrow",
        tier: 1,
        ascendancies: &["Deadeye", "Pathfinder"],
    },
    ClassProfile {
        id: "huntress",
        name: "Охотница с копьём",
        english: "Huntress",
        style: "spear",
        styles: &["spear"],
        starter: "Lightning_Spear",
        tier: 3,
        ascendancies: &["Amazon", "Spirit Walker", "Ritualist"],
    },
    ClassProfile {
        id: "warrior",
        name: "Воин",
        english: "Warrior",
        style: "melee",
        styles: &["melee"],
        starter: "Rolling_Slam",
        tier: 1,
        ascendancies: &["Titan", "Warbringer", "Smith of Kitava"],
    },
    ClassProfile {
        id: "mercenary",
        name: "Наёмник",
        english: "Mercenary",
        style: "crossbow",
        styles: &["crossbow"],
        starter: "Galvanic_Shards",
        tier: 5,
        ascendancies: &["Tactician", "Witchhunter", "Gemling Legionnaire"],
    },
    ClassProfile {
        id: "sorceress",
        name: "Колдунья",
        english: "Sorceress",
        style: "caster",
        styles: &["caster"],
        starter: "Spark",
        tier: 1,
        ascendancies: &["Stormweaver", "Chronomancer", "Disciple of Varashta"],
    },
    ClassProfile {
        id: "monk",
        name: "Монах",
        english: "Monk",
        style: "staff",
        styles: &["staff"],
        starter: "Tempest_Flurry",
        tier: 5,
        ascendancies: &["Martial Artist", "Invoker", "Acolyte of Chayula"],
    },
];

fn normalize(input: &str) -> String {
    input
        .chars()
        .filter(|c| c.is_ascii_alphanumeric())
        .map(|c| c.to_ascii_lowercase())
        .collect()
}

pub fn find_class(name: &str) -> Option<(&'static ClassProfile, Option<&'static str>)> {
    let wanted = normalize(name);
    CLASSES.iter().find_map(|class| {
        if normalize(class.english) == wanted {
            return Some((class, None));
        }
        class
            .ascendancies
            .iter()
            .copied()
            .find(|name| normalize(name) == wanted)
            .map(|name| (class, Some(name)))
    })
}

pub fn select_class(
    name: &str,
    style: Option<&str>,
) -> Result<(&'static ClassProfile, &'static str), String> {
    let class = if name == "auto" {
        let style = style.unwrap_or("bear");
        CLASSES
            .iter()
            .find(|class| class.style == style)
            .or_else(|| CLASSES.iter().find(|class| class.styles.contains(&style)))
            .ok_or_else(|| "Неизвестный стиль игры.".to_owned())?
    } else {
        find_class(name)
            .map(|(class, _)| class)
            .ok_or_else(|| "Неизвестный класс.".to_owned())?
    };
    let style = style.unwrap_or(class.style);
    let style = class
        .styles
        .iter()
        .copied()
        .find(|available| *available == style)
        .ok_or_else(|| {
            format!(
                "Этот стиль недоступен для класса «{}» в планировщике.",
                class.name
            )
        })?;
    Ok((class, style))
}

#[derive(Deserialize)]
struct Export {
    #[serde(default)]
    characters: Option<Vec<Entry>>,
    #[serde(default)]
    character: Option<Entry>,
}
#[derive(Deserialize)]
struct Entry {
    name: String,
    class: String,
    level: u16,
    league: Option<String>,
    #[serde(default)]
    deleted: bool,
    passives: Option<Passives>,
    #[serde(default)]
    skills: Vec<Value>,
    #[serde(default)]
    equipment: Vec<Value>,
}
#[derive(Deserialize)]
struct Passives {
    hashes: Vec<u32>,
}

pub fn roster(input: &str) -> Result<Value, String> {
    let export: Export =
        serde_json::from_str(input.trim_start_matches('\u{feff}')).map_err(|_| {
            "Нужен JSON из официального API: список characters или один character.".to_owned()
        })?;
    let entries = match (export.characters, export.character) {
        (Some(entries), None) => entries,
        (None, Some(entry)) => vec![entry],
        _ => return Err("В файле должен быть список characters или один character.".to_owned()),
    };
    let mut skipped = 0;
    let characters: Vec<_> = entries
        .into_iter()
        .filter_map(|entry| {
            let class = find_class(&entry.class);
            if entry.deleted
                || !(1..=100).contains(&entry.level)
                || entry.name.trim().is_empty()
                || class.is_none()
            {
                skipped += 1;
                return None;
            }
            let (class, ascendancy) = class?;
            Some(json!({
                "name":entry.name, "class":class.id, "class_name":class.name,
                "ascendancy":ascendancy, "level":entry.level, "league":entry.league,
                "passives":entry.passives.map(|p|p.hashes).unwrap_or_default(),
                "equipment":entry.equipment.len(), "skills":entry.skills.len(),
            }))
        })
        .collect();
    Ok(json!({"characters":characters,"skipped":skipped}))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn catalog_has_eight_playable_classes_and_twenty_two_ascendancies() {
        assert_eq!(CLASSES.len(), 8);
        assert_eq!(
            CLASSES.iter().map(|c| c.ascendancies.len()).sum::<usize>(),
            22
        );
        assert_eq!(
            select_class("auto", Some("caster")).unwrap().0.id,
            "sorceress"
        );
    }

    #[test]
    fn class_selection_validates_style() {
        assert!(select_class("druid", Some("staff")).is_err());
        assert_eq!(select_class("auto", Some("wolf")).unwrap().0.id, "druid");
        assert_eq!(select_class("monk", None).unwrap().1, "staff");
    }
    #[test]
    fn ascendancy_names_resolve_to_base_classes_in_api_import() {
        let value = roster(r#"{"characters":[{"name":"A","class":"Disciple of Varashta","level":84,"league":"SSF","passives":{"hashes":[12,45]}},{"name":"B","class":"Infernalist","level":20},{"name":"C","class":"Monk","level":104}]}"#).unwrap();
        assert_eq!(value["characters"][0]["class"], "sorceress");
        assert_eq!(value["characters"][0]["passives"][1], 45);
        assert_eq!(value["characters"][1]["ascendancy"], "Infernalist");
        assert_eq!(value["skipped"], 1);
    }
}
