use serde::Deserialize;
use std::{collections::BTreeMap, fs, path::Path};

pub const SOURCE: &str = "https://poe2db.tw/us/";
pub const ACTS_GUIDE: &str = "https://mobalytics.gg/poe-2/builds/meteor-bear-druid#passive-tree";
pub const ATTACKS: &[&str] = &["Furious_Slam", "Lunar_Assault", "Rampage"];
pub const SPELLS: &[&str] = &["Volcano", "Entangle", "Thunderstorm"];

#[derive(Deserialize)]
pub struct Snapshot {
    schema: u8,
    pub retrieved: String,
    source: String,
    pub gems: BTreeMap<String, Gem>,
    pub supports: BTreeMap<String, Support>,
}

#[derive(Deserialize)]
pub struct Gem {
    pub tier: u8,
    #[serde(default)]
    pub speed: f64,
    #[serde(default)]
    pub cold: f64,
    #[serde(default)]
    pub spirit: u16,
    #[serde(default)]
    pub levels: Vec<Level>,
}

#[derive(Deserialize)]
pub struct Level {
    pub requires: u16,
    pub values: Vec<f64>,
}

#[derive(Deserialize)]
pub struct Support {
    pub tier: u8,
    pub value: f64,
    #[serde(default)]
    pub secondary: f64,
    #[serde(default)]
    pub spirit: u16,
}

impl Snapshot {
    pub fn load(path: Option<&Path>) -> Result<Self, String> {
        let input = match path {
            Some(path) => {
                fs::read_to_string(path).map_err(|err| format!("{}: {err}", path.display()))?
            }
            None => include_str!("../data/poe2db.json").to_owned(),
        };
        let data: Self = serde_json::from_str(input.trim_start_matches('\u{feff}'))
            .map_err(|err| err.to_string())?;
        if data.schema != 1 || data.source != SOURCE || data.retrieved.is_empty() {
            return Err("Неподдерживаемый формат или источник данных камней.".into());
        }
        for (id, len) in [
            ("Furious_Slam", 4),
            ("Lunar_Assault", 3),
            ("Rampage", 3),
            ("Volcano", 2),
            ("Entangle", 2),
            ("Thunderstorm", 2),
            ("Time_of_Need", 2),
            ("Ferocious_Roar", 0),
            ("Arctic_Howl", 0),
        ] {
            let gem = data
                .gems
                .get(id)
                .ok_or_else(|| format!("Отсутствует {id}."))?;
            let tier_ok = (1..=20).contains(&gem.tier);
            let levels_ok = len == 0
                || (gem.levels.len() == 20
                    && gem.levels.iter().all(|row| {
                        row.values.len() == len
                            && row
                                .values
                                .iter()
                                .all(|&x| x.is_finite() && x > 0.0 && x <= 100_000.0)
                    }));
            if !tier_ok
                || !levels_ok
                || !(0.0..=100.0).contains(&gem.cold)
                || (ATTACKS.contains(&id) && !(1.0..=500.0).contains(&gem.speed))
                || (id == "Time_of_Need" && gem.spirit == 0)
            {
                return Err(format!("Неполные или некорректные данные {id}."));
            }
        }
        for id in [
            "Brutality_I",
            "Brutality_II",
            "Rapid_Attacks_I",
            "Rapid_Attacks_II",
            "Heavy_Swing",
            "Magnified_Area_I",
            "Magnified_Area_II",
            "Vitality_I",
            "Vitality_II",
        ] {
            let support = data
                .supports
                .get(id)
                .ok_or_else(|| format!("Отсутствует {id}."))?;
            if !(1..=5).contains(&support.tier)
                || !(0.0..=100.0).contains(&support.value)
                || !(0.0..100.0).contains(&support.secondary)
                || (id.starts_with("Vitality") && support.spirit == 0)
            {
                return Err(format!("Некорректная поддержка {id}."));
            }
        }
        Ok(data)
    }
}

pub fn name(id: &str) -> String {
    id.replace('_', " ")
}
