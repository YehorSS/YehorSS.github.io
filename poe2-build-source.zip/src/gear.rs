use crate::{
    catalog::{name, Snapshot},
    planner::{best_attack, gem_allowed, Goal},
    Options,
};
use serde::Deserialize;
use serde::Serialize;
use std::{collections::HashSet, fs, path::Path};

#[derive(Clone, Copy, Deserialize)]
#[serde(deny_unknown_fields)]
struct Attributes {
    str: u16,
    dex: u16,
    int: u16,
}
impl Attributes {
    fn array(self) -> [u32; 3] {
        [self.str.into(), self.dex.into(), self.int.into()]
    }
}
#[derive(Clone, Copy, PartialEq, Eq, Deserialize)]
#[serde(rename_all = "snake_case")]
enum Slot {
    Talisman,
    Helmet,
    Body,
    Gloves,
    Boots,
    Belt,
    Amulet,
    Ring,
}
#[derive(Deserialize)]
#[serde(rename_all = "snake_case")]
enum Location {
    Inventory,
    Stash,
    Equipped,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Item {
    id: String,
    name: String,
    league: String,
    slot: Slot,
    location: Location,
    confirmed: bool,
    required_level: u16,
    requires: Attributes,
    grants: Attributes,
    #[serde(default)]
    life: u16,
    #[serde(default)]
    increased_area: u16,
    #[serde(default)]
    physical_damage: Option<[u16; 2]>,
    #[serde(default)]
    attacks_per_second: Option<f64>,
    #[serde(default)]
    limit_group: Option<String>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Import {
    schema: u8,
    league: String,
    level: u16,
    base_attributes: Attributes,
    base_life: u32,
    items: Vec<Item>,
}

struct Best {
    value: f64,
    sequence: Vec<usize>,
    detail: String,
}
struct Search<'a> {
    items: Vec<&'a Item>,
    seen: HashSet<Vec<usize>>,
    best: Option<Best>,
    data: &'a Snapshot,
    o: &'a Options,
    import: &'a Import,
    skills: Vec<&'static str>,
    skipped: Vec<String>,
}
impl Search<'_> {
    fn measure(&self, sequence: &[usize]) -> Option<(f64, String)> {
        let items = sequence.iter().map(|&i| self.items[i]);
        match self.o.goal {
            Goal::Survival => {
                let (extra, strength) = items.fold((0_u32, 0_u32), |(hp, str), item| {
                    (hp + u32::from(item.life), str + u32::from(item.grants.str))
                });
                let life = self.import.base_life + extra + 2 * strength;
                Some((life.into(), format!("Живучесть: {} HP без экипировки + {extra} плоского HP + 2×{strength} от силы = {life} HP.", self.import.base_life)))
            }
            Goal::Clear => {
                let has_talisman = items.clone().any(|item| item.slot == Slot::Talisman);
                let skill = self
                    .skills
                    .iter()
                    .find(|&&id| id == "Thunderstorm" || has_talisman)?;
                let bonus: u32 = items.map(|item| u32::from(item.increased_area)).sum();
                let support = ["Magnified_Area_II", "Magnified_Area_I"]
                    .into_iter()
                    .find(|id| {
                        self.o.sockets > 0 && self.data.supports[*id].tier <= self.o.support_tier
                    });
                let gem_bonus = support.map_or(0.0, |id| self.data.supports[id].value);
                let multiplier = 1.0 + (f64::from(bonus) + gem_bonus) / 100.0;
                Some((multiplier, format!("{}: площадь ×{multiplier:.2} = 1 + ({bonus}% с вещей + {gem_bonus}% с камня)/100.", name(skill))))
            }
            Goal::Damage => {
                let weapon = items.into_iter().find(|item| item.slot == Slot::Talisman)?;
                let [min, max] = weapon.physical_damage?;
                let aps = weapon.attacks_per_second?;
                let hit = (f64::from(min) + f64::from(max)) / 2.0;
                self.skills.iter().map(|&id| {
                    let (attack, supports) = best_attack(self.data, id, self.o, hit, aps);
                    let chosen = std::iter::once(id).chain(supports).map(name).collect::<Vec<_>>().join(" + ");
                    let dps = attack.dps();
                    (dps, format!("{chosen} — {dps:.3} модельного урона/с = ({:.3} физ. + {:.3} холод) × {:.3} атак/с. Талисман: {min}–{max} физ., {aps} атак/с.",
                        attack.physical, attack.cold, attack.attacks_per_second))
                }).max_by(|a, b| a.0.total_cmp(&b.0))
            }
            Goal::Balanced => None,
        }
    }

    fn traverse(&mut self, sequence: &mut Vec<usize>, have: [u32; 3]) {
        let mut key = sequence.clone();
        key.sort_unstable();
        if !self.seen.insert(key) {
            return;
        }
        if let Some((value, detail)) = self.measure(sequence) {
            if self.best.as_ref().is_none_or(|b| {
                value > b.value || (value == b.value && sequence.len() < b.sequence.len())
            }) {
                self.best = Some(Best {
                    value,
                    sequence: sequence.clone(),
                    detail,
                });
            }
        }
        for idx in 0..self.items.len() {
            let item = self.items[idx];
            if sequence.contains(&idx)
                || have
                    .iter()
                    .zip(item.requires.array())
                    .any(|(&have, need)| have < need)
            {
                continue;
            }
            let capacity = if item.slot == Slot::Ring { 2 } else { 1 };
            if sequence
                .iter()
                .filter(|&&i| self.items[i].slot == item.slot)
                .count()
                >= capacity
                || item.limit_group.as_ref().is_some_and(|group| {
                    sequence
                        .iter()
                        .any(|&i| self.items[i].limit_group.as_ref() == Some(group))
                })
            {
                continue;
            }
            let gain = item.grants.array();
            sequence.push(idx);
            self.traverse(sequence, std::array::from_fn(|i| have[i] + gain[i]));
            sequence.pop();
        }
    }
}

fn solve<'a>(import: &'a Import, data: &'a Snapshot, o: &'a Options) -> Result<Search<'a>, String> {
    if o.goal == Goal::Balanced {
        return Err("Для вещей выбери одну измеряемую цель: damage, survival или clear.".into());
    }
    if import.schema != 1
        || import.league.is_empty()
        || !(1..=100).contains(&import.level)
        || !(1..=1_000_000).contains(&import.base_life)
    {
        return Err("Проверь схему, лигу, уровень и базовый HP.".into());
    }
    let mut ids = HashSet::new();
    let mut items = Vec::new();
    let mut skipped = Vec::new();
    for i in &import.items {
        if i.id.is_empty() || !ids.insert(&i.id) {
            return Err("Каждому предмету нужен уникальный id.".into());
        }
        let valid_weapon = match (i.slot, i.physical_damage, i.attacks_per_second) {
            (Slot::Talisman, Some([min, max]), Some(aps)) => {
                min <= max && max > 0 && (0.001..=100.0).contains(&aps)
            }
            (slot, None, None) => slot != Slot::Talisman,
            _ => false,
        };
        if i.confirmed
            && i.league == import.league
            && i.required_level <= import.level
            && valid_weapon
        {
            items.push(i);
        } else {
            skipped.push(i.name.clone());
        }
    }
    let candidates: &[&str] = if o.goal == Goal::Clear {
        &["Furious_Slam", "Lunar_Assault", "Thunderstorm", "Rampage"]
    } else {
        &["Furious_Slam", "Lunar_Assault"]
    };
    let skills = candidates
        .iter()
        .copied()
        .filter(|&id| {
            gem_allowed(data, o, id) && data.gems[id].levels[o.level - 1].requires <= import.level
        })
        .collect();
    let mut search = Search {
        items,
        seen: HashSet::new(),
        best: None,
        data,
        o,
        import,
        skills,
        skipped,
    };
    search.traverse(&mut Vec::new(), import.base_attributes.array());
    Ok(search)
}

#[derive(Serialize)]
pub struct GearReport {
    pub checked: usize,
    pub detail: Option<String>,
    pub sequence: Vec<GearStep>,
    pub skipped: Vec<String>,
}

#[derive(Serialize)]
pub struct GearStep {
    pub name: String,
    pub id: String,
    pub location: &'static str,
}

pub fn report(content: &str, data: &Snapshot, o: &Options) -> Result<GearReport, String> {
    let import: Import = serde_json::from_str(content.trim_start_matches('\u{feff}'))
        .map_err(|err| err.to_string())?;
    let search = solve(&import, data, o)?;
    let mut sequence = Vec::new();
    let detail = search.best.map(|best| {
        for idx in best.sequence {
            let i = search.items[idx];
            sequence.push(GearStep {
                name: i.name.clone(),
                id: i.id.clone(),
                location: match i.location {
                    Location::Inventory => "Инвентарь",
                    Location::Stash => "Тайник",
                    Location::Equipped => "Надет",
                },
            });
        }
        best.detail
    });
    Ok(GearReport {
        checked: search.seen.len(),
        detail,
        sequence,
        skipped: search.skipped,
    })
}

pub fn run(path: &Path, data: &Snapshot, o: &Options) -> Result<(), String> {
    let content = fs::read_to_string(path).map_err(|err| err.to_string())?;
    let report = report(&content, data, o)?;
    for name in report.skipped {
        println!("Пропущен: {name} — проверь требования, лигу и полноту данных.");
    }
    println!(
        "Проверено {} наборов, которые можно надеть из этого списка (включая пустой).",
        report.checked
    );
    if let Some(detail) = report.detail {
        println!("{detail}");
        println!("Порядок надевания победившего набора:");
        for (step, item) in report.sequence.into_iter().enumerate() {
            println!(
                "  {}. {} [{}; ID {}]",
                step + 1,
                item.name,
                item.location,
                item.id
            );
        }
    } else {
        println!("Из этого списка и параметров нет комплекта с рассчитываемым результатом.");
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn gear_order_and_eligibility() {
        let import: Import =
            serde_json::from_str(include_str!("../examples/inventory.example.json")).unwrap();
        let data = Snapshot::load(None).unwrap();
        let options = Options::default();
        let result = solve(&import, &data, &options).unwrap();
        let picked: Vec<_> = result
            .best
            .unwrap()
            .sequence
            .iter()
            .map(|&index| result.items[index].id.as_str())
            .collect();
        assert_eq!(picked, ["str-ring", "equippable-talisman"]);
    }
}
