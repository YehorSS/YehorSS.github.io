import { copyFile, mkdir, readFile, writeFile } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const root = new URL("../", import.meta.url);
const project = fileURLToPath(root);
const destination = new URL("../dist/", import.meta.url);
const local = process.argv.includes("--native");
const build = local
  ? ["build", "--locked", "--release", "--bin", "poe2-web-engine"]
  : ["build", "--locked", "--release", "--lib", "--target", "wasm32-unknown-unknown"];
const result = spawnSync("cargo", build, { cwd: project, stdio: "inherit" });
if (result.error) throw result.error;
if (result.status !== 0) process.exit(result.status ?? 1);
await mkdir(destination, { recursive: true });
for (const name of ["app.js", "style.css", "hero.jpg", "witch.jpg", "web-worker.js"]) {
  await copyFile(new URL("ui/" + name, root), new URL(name, destination));
}
const html = await readFile(new URL("ui/index.html", root), "utf8");
await writeFile(new URL("index.html", destination), html.replace(
  "script-src 'self'", "script-src 'self' 'wasm-unsafe-eval'; worker-src 'self'; connect-src 'self'",
));
await writeFile(new URL(".nojekyll", destination), "");
if (!local) await copyFile(
  new URL("target/wasm32-unknown-unknown/release/poe2_build.wasm", root),
  new URL("poe2_build.wasm", destination),
);
console.log(local ? "Local preview assets are ready." : "Static website is ready in dist/.");
