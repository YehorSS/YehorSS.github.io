"""Export a PoE 2 roster or character using a registered GGG OAuth client."""
import argparse
import base64
import hashlib
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from pathlib import Path
import secrets
import sys
import time
from urllib.error import HTTPError
from urllib.parse import parse_qs, quote, urlencode, urlsplit
from urllib.request import build_opener, HTTPRedirectHandler, Request
import webbrowser

OAUTH = "https://www.pathofexile.com/oauth/"
API = "https://api.pathofexile.com"


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *_):
        return None


def digest_url(value):
    return base64.urlsafe_b64encode(hashlib.sha256(value.encode("ascii")).digest()).decode("ascii").rstrip("=")


def login(client_id, port):
    verifier = secrets.token_urlsafe(48)
    state = secrets.token_urlsafe(32)
    redirect = f"http://127.0.0.1:{port}/callback"
    consent = OAUTH + "authorize?" + urlencode({
        "client_id": client_id, "response_type": "code", "scope": "account:characters",
        "state": state, "redirect_uri": redirect,
        "code_challenge": digest_url(verifier), "code_challenge_method": "S256",
    })

    class Callback(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def do_GET(self):
            parsed = urlsplit(self.path)
            query = parse_qs(parsed.query)
            valid = (parsed.path == "/callback" and len(query.get("state", [])) == 1
                     and secrets.compare_digest(query["state"][0], state))
            if valid:
                self.server.result = query
            self.send_response(200 if valid else 404)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(b"Return to the terminal." if valid else b"Invalid callback.")

    with HTTPServer(("127.0.0.1", port), Callback) as server:
        server.timeout = 1
        server.result = None
        print("Войди на сайте GGG и разреши чтение персонажей.")
        if not webbrowser.open(consent):
            print(consent)
        deadline = time.monotonic() + 180
        while server.result is None and time.monotonic() < deadline:
            server.handle_request()
        codes = (server.result or {}).get("code", [])
        if len(codes) != 1:
            raise ValueError("GGG не вернула код авторизации или истекло время ожидания.")
    return urlencode({
        "grant_type": "authorization_code", "client_id": client_id, "code": codes[0],
        "redirect_uri": redirect, "code_verifier": verifier,
    }).encode("ascii")


def get_json(opener, request):
    with opener.open(request, timeout=20) as response:
        return json.load(response)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--client-id", required=True)
    parser.add_argument("--contact", required=True, help="contact address registered with GGG for the application")
    parser.add_argument("--port", required=True, type=int, choices=range(1024, 65536), metavar="REGISTERED_PORT")
    parser.add_argument("--character", help="omit to export the account's character list")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("Укажи новый файл для экспорта персонажа.")
    agent = f"OAuth {args.client_id}/0.2.0 (contact: {args.contact})"
    if not agent.isascii() or "\r" in agent or "\n" in agent:
        raise ValueError("Проверь параметры приложения GGG.")
    opener = build_opener(NoRedirect)
    headers = {"User-Agent": agent, "Accept": "application/json"}
    data = login(args.client_id, args.port)
    token = get_json(opener, Request(OAUTH + "token", data=data, headers={
        **headers, "Content-Type": "application/x-www-form-urlencoded",
    })).get("access_token")
    if not token:
        raise ValueError("Ответ OAuth не содержит access token.")
    path = "/character/poe2"
    if args.character:
        path += "/" + quote(args.character, safe="")
    response = get_json(opener, Request(API + path, headers={
        **headers, "Authorization": "Bearer " + token,
    }))
    if not isinstance(response, dict) or (
        not isinstance(response.get("character"), dict) if args.character
        else not isinstance(response.get("characters"), list)
    ):
        raise ValueError("GGG не вернула ожидаемые данные персонажей.")
    with args.output.open("x", encoding="utf-8") as output:
        json.dump(response, output, ensure_ascii=False, indent=2)
        output.write("\n")
    print(f"Данные персонажей экспортированы в {args.output}")


if __name__ == "__main__":
    try:
        main()
    except HTTPError as exc:
        sys.exit(f"GGG вернула HTTP {exc.code}. Проверь клиент, право account:characters и имя игрока.")
    except (ValueError, OSError) as exc:
        sys.exit(str(exc))
