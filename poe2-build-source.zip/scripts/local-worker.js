"use strict";

// Used only by the loopback preview when the Wasm target is unavailable.
self.onmessage = async ({ data: request }) => {
  try {
    const response = await fetch("./calculate", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(request),
    });
    if (!response.ok) throw new Error("Локальный расчёт не завершился.");
    self.postMessage({ ...await response.json(), id: request.id });
  } catch (e) {
    self.postMessage({ id: request.id, error: e.message });
  }
};
