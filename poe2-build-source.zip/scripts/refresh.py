"""Fetch the calculator's supported numerical fields from English PoE2DB."""
import argparse
import datetime
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import sys
from urllib.request import Request, urlopen

SOURCE = "https://poe2db.tw/us/"
ATTACKS = ("Furious_Slam", "Lunar_Assault", "Rampage")
SPELLS = ("Volcano", "Entangle", "Thunderstorm")
SUPPORTS = {
    "Brutality_I": r"(\d+)\s*% more Physical Damage",
    "Brutality_II": r"(\d+)\s*% more Physical Damage",
    "Rapid_Attacks_I": r"(\d+)\s*% increased Attack Speed",
    "Rapid_Attacks_II": r"(\d+)\s*% increased Attack Speed",
    "Heavy_Swing": r"(\d+)\s*% more Melee Physical Damage",
    "Magnified_Area_I": r"(\d+)\s*% increased Area of Effect",
    "Magnified_Area_II": r"(\d+)\s*% increased Area of Effect",
    "Vitality_I": r"Regenerate (\d+)\s*% of maximum Life per second",
    "Vitality_II": r"Regenerate (\d+)\s*% of maximum Life per second",
}


class Page(HTMLParser):
    def __init__(self, html):
        super().__init__(convert_charrefs=True)
        self.words = []
        self.tables = []
        self.table = self.row = self.cell = None
        self.hidden = None
        self.feed(html)
        self.text = " ".join(" ".join(self.words).split())

    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style"}:
            self.hidden = tag
        if tag == "table":
            self.table = []
        elif tag == "tr":
            self.row = []
        elif tag in {"th", "td"}:
            self.cell = []

    def handle_endtag(self, tag):
        if tag == self.hidden:
            self.hidden = None
        if tag == "table" and self.table is not None:
            self.tables.append(self.table)
            self.table = None
        elif tag == "tr" and self.table is not None and self.row is not None:
            self.table.append(self.row)
            self.row = None
        elif tag in {"th", "td"} and self.row is not None and self.cell is not None:
            self.row.append(" ".join(" ".join(self.cell).split()))
            self.cell = None

    def handle_data(self, data):
        if self.hidden:
            return
        self.words.append(data)
        if self.cell is not None:
            self.cell.append(data)


def number(text, pattern, cast=int):
    found = re.search(pattern, text, re.IGNORECASE)
    if not found:
        raise ValueError(f"missing source field matching {pattern}")
    return cast(found[1])


def range_values(cell, expected):
    parts = cell.split(",")
    if len(parts) != expected:
        raise ValueError(f"expected {expected} values, got {cell}")
    return [int(part.strip().removesuffix("%").strip()) for part in parts]


def level_rows(page, gem):
    table = next((t for t in page.tables if t and t[0][:2] == ["Level", "Requires Level"]
                  and "Base Damage" in t[0]), None)
    if table is None:
        raise ValueError("skill level table not found")
    header = table[0]
    damage = header.index("Base Damage")
    if gem in SPELLS and not header[damage + 1].startswith("Deals "):
        raise ValueError("first hit data column changed")
    if gem == "Time_of_Need":
        if "seconds between Blessings" not in header[damage + 1] or not header[damage + 2].startswith("Blessing recovers"):
            raise ValueError("blessing data columns changed")
    rows = []
    for row in table[1:21]:
        if int(row[0]) != len(rows) + 1:
            raise ValueError("skill levels are not sequential")
        if gem in ATTACKS:
            values = range_values(row[damage], 4 if gem == "Furious_Slam" else 3)
        elif gem in SPELLS:
            values = range_values(row[damage + 1], 2)
        else:
            values = [float(row[damage + 1]), int(row[damage + 2])]
        if not all(0 < value <= 100_000 for value in values):
            raise ValueError("out-of-range level data")
        rows.append({"requires": int(row[1]), "values": values})
    if len(rows) != 20:
        raise ValueError("expected rows for all 20 skill levels")
    return rows


def download(gem):
    request = Request(SOURCE + gem, headers={"User-Agent": "PoE2-Build/0.2 (manual gem data refresh)"})
    with urlopen(request, timeout=15) as response:
        if response.geturl() != SOURCE + gem:
            raise ValueError("unexpected source redirect")
        return response.read().decode("utf-8")


def snapshot(fetch=download):
    gems = {}
    for gem in (*ATTACKS, *SPELLS, "Time_of_Need", "Ferocious_Roar", "Arctic_Howl"):
        try:
            page = Page(fetch(gem))
            row = {"tier": number(page.text, r"\bTier:\s*(\d+)")}
            if gem in (*ATTACKS, *SPELLS, "Time_of_Need"):
                row["levels"] = level_rows(page, gem)
            if gem in ATTACKS:
                row["speed"] = number(page.text, r"Attack Speed:\s*(\d+)\s*% of base")
            if gem == "Lunar_Assault":
                row["cold"] = number(page.text, r"Converts (\d+)\s*% of Physical damage to Cold damage")
            if gem == "Time_of_Need":
                row["spirit"] = number(page.text, r"Reservation:\s*(\d+) Spirit")
            gems[gem] = row
        except (ValueError, OSError, IndexError) as exc:
            raise ValueError(f"{gem}: {exc}") from exc
    supports = {}
    for gem, effect in SUPPORTS.items():
        try:
            page = Page(fetch(gem))
            tier = number(page.text, r"Uncut Support Gem\s*Tier\s*(\d+)")
            effect_table = next(t for t in page.tables if t and t[0] == ["Implicit"])
            text = " ".join(" ".join(row) for row in effect_table[1:])
            row = {"tier": tier, "value": number(text, effect)}
            if gem == "Heavy_Swing":
                row["secondary"] = number(text, r"(\d+)\s*% less Attack Speed")
            if gem.startswith("Brutality"):
                for damage_type in ("Elemental", "Chaos"):
                    if not re.search(rf"deal no {damage_type} Damage", text, re.IGNORECASE):
                        raise ValueError("Brutality damage exclusions changed")
            if gem.startswith("Vitality"):
                # PoE2DB places the flat Spirit reservation in this effect-table field.
                row["spirit"] = number(text, r"Mana:\s*(\d+)\b(?!\s*%)")
            supports[gem] = row
        except (ValueError, OSError, StopIteration) as exc:
            raise ValueError(f"{gem}: {exc or 'support effect table missing'}") from exc
    return {"schema": 1, "retrieved": datetime.date.today().isoformat(), "source": SOURCE, "gems": gems, "supports": supports}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, help="new snapshot file (an existing file is preserved)")
    args = parser.parse_args()
    try:
        result = snapshot()
        with args.output.open("x", encoding="utf-8") as output:
            json.dump(result, output, indent=2, ensure_ascii=False)
            output.write("\n")
        print(args.output)
    except (ValueError, OSError) as exc:
        sys.exit(f"Не удалось обновить данные: {exc}")
