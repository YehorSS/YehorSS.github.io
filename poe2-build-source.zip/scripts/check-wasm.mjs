import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const native = process.argv.includes("--native");
const root = new URL("../", import.meta.url);
const wasm = native ? null : (await WebAssembly.instantiate(await readFile(new URL("dist/poe2_build.wasm", root)))).instance.exports;
const encoder = new TextEncoder();
const decoder = new TextDecoder();
function request(action, params = {}, payload = "") {
  const input = encoder.encode(JSON.stringify({id: 23, action, params, input: payload}));
  let output;
  if (wasm) {
    const ptr = wasm.prepare_request(input.length);
    assert.notEqual(ptr, 0);
    new Uint8Array(wasm.memory.buffer, ptr, input.length).set(input);
    wasm.process_request();
    output = decoder.decode(new Uint8Array(wasm.memory.buffer, wasm.response_ptr(), wasm.response_len()));
  } else {
    const suffix = process.platform === "win32" ? ".exe" : "";
    const run = spawnSync(fileURLToPath(new URL("target/release/poe2-web-engine" + suffix, root)), {
      input, encoding: "utf8", windowsHide: true,
    });
    if (run.error) throw run.error;
    assert.equal(run.status, 0);
    output = run.stdout;
  }
  const reply = JSON.parse(output);
  assert.equal(reply.id, 23);
  assert.ok(!reply.error, reply.error);
  return reply.result;
}
assert.equal(request("gems").cards[0].name, "Furious Slam");
const minions = request("gems", { "playstyle": "minion", "phase": "endgame", "spirit": "150" });
assert.equal(minions.cards[0].value, 5);
assert.equal(minions.profile.picks[0].name, "Infernalist");
assert.ok(request("gear", {goal:"survival"}).checked > 0);
const route = request("tree", {demo:"1",start:"1",target:"3"});
assert.equal(route.route.steps.length, 2);
const classes = request("classes").classes;
assert.equal(classes.length, 8);
assert.equal(classes.flatMap(c => c.ascendancies).length, 22);
for (const c of classes) {
  const result = request("gems", {character:c.id,playstyle:c.style,phase:"endgame",spirit:"150"});
  assert.equal(result.profile.class_id, c.id);
  assert.ok(result.cards.length > 0, c.id);
}
const roster = request("characters", {}, JSON.stringify({characters:[{name:"Test",class:"Deadeye",level:42,league:"Example"}]}));
assert.equal(roster.characters[0].ascendancy, "Deadeye");
assert.equal(roster.characters[0].class, "ranger");
assert.equal(request("gems",{character:"ranger",playstyle:"bow","gem-level":"20","character-level":"42"}).cards.length,0);
console.log((native ? "Native" : "WebAssembly") + ": gems, minions, equipment, tree and roster verified.");
