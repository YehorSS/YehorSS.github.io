import { spawn } from "node:child_process";
import { readFile } from "node:fs/promises";
import { createServer } from "node:http";
import { fileURLToPath } from "node:url";

const root = new URL("../", import.meta.url);
const port = Number(process.argv[2] ?? 4173);
const address = "127.0.0.1";
const origin = "http://" + address + ":" + port;
const useNative = process.argv.includes("--native");
const nativeName = "poe2-web-engine" + (process.platform === "win32" ? ".exe" : "");
const archived = process.argv.includes("--bundled");
const engine = fileURLToPath(new URL((archived ? "preview/" : "target/release/") + nativeName, root));
const types = {
  "/index.html": "text/html; charset=utf-8", "/style.css": "text/css; charset=utf-8",
  "/app.js": "text/javascript; charset=utf-8", "/web-worker.js": "text/javascript; charset=utf-8",
  "/poe2_build.wasm": "application/wasm", "/hero.jpg": "image/jpeg", "/witch.jpg": "image/jpeg",
};
const maxInput = 16 * 1024 * 1024;
let running = 0;

function calculate(input) {
  return new Promise((resolve, reject) => {
    const child = spawn(engine, [], { stdio: ["pipe", "pipe", "ignore"], windowsHide: true, timeout: 30_000 });
    const output = [];
    child.stdout.on("data", chunk => output.push(chunk));
    child.stdin.on("error", reject);
    child.on("error", reject);
    child.on("close", code => code === 0 ? resolve(Buffer.concat(output)) : reject(new Error("Calculation failed.")));
    child.stdin.end(input);
  });
}

const server = createServer(async (request, response) => {
  response.setHeader("X-Content-Type-Options", "nosniff");
  if (request.headers.host !== address + ":" + port) { response.writeHead(403).end(); return; }
  const path = (request.url ?? "").split("?")[0];
  if (useNative && path === "/calculate" && request.method === "POST") {
    if (request.headers.origin !== origin || request.headers["content-type"] !== "application/json") {
      response.writeHead(403).end(); return;
    }
    if (running >= 4) { response.writeHead(503).end(); return; }
    running++;
    try {
      const parts = [];
      let size = 0;
      for await (const chunk of request) {
        size += chunk.length;
        if (size > maxInput) { response.writeHead(413).end(); return; }
        parts.push(chunk);
      }
      const result = await calculate(Buffer.concat(parts));
      response.writeHead(200, { "Content-Type": "application/json; charset=utf-8" }).end(result);
    } catch { response.writeHead(500).end(); }
    finally { running--; }
    return;
  }
  const asset = path === "/" ? "/index.html" : path;
  if (request.method !== "GET" || !Object.hasOwn(types, asset)) { response.writeHead(404).end(); return; }
  try {
    const name = useNative && asset === "/web-worker.js" ? "scripts/local-worker.js" : "dist" + asset;
    const contents = await readFile(new URL(name, root));
    response.writeHead(200, { "Content-Type": types[asset] }).end(contents);
  } catch { response.writeHead(404).end(); }
});
server.listen(port, address, () => {
  console.log("PoE2 Build: " + origin);
  if (process.platform === "win32" && process.argv.includes("--open")) {
    const browser = spawn("rundll32.exe", ["url.dll,FileProtocolHandler", origin], { stdio: "ignore", windowsHide: true });
    browser.on("error", () => {});
  }
});
