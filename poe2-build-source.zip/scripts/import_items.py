"""Import supported English PoE 2 Ctrl+C item dumps from local folders."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

SLOTS = {
    "Talismans": "talisman", "Helmets": "helmet", "Body Armours": "body",
    "Gloves": "gloves", "Boots": "boots", "Belts": "belt",
    "Amulets": "amulet", "Rings": "ring",
}
ATTRS = {"Strength": "str", "Dexterity": "dex", "Intelligence": "int"}
SKIP_FLAGS = {"Corrupted", "Mirrored", "Split", "Unmodifiable"}
LOCAL_WEAPON = (
    r"[+\-]?\d+(?:\.\d+)?% increased Physical Damage",
    r"Adds \d+ to \d+ Physical Damage",
    r"[+\-]?\d+(?:\.\d+)?% increased Attack Speed",
)


def blank_stats():
    return dict.fromkeys(ATTRS.values(), 0)


def read_item(text, item_id, league, location):
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    sections = [[]]
    for line in lines:
        if re.fullmatch(r"-{4,}", line):
            sections.append([])
        else:
            sections[-1].append(line)
    header = sections[0]
    if len(header) < 3 or not header[0].startswith("Item Class: ") or not header[1].startswith("Rarity: "):
        raise ValueError("требуется полный английский текст предмета из Ctrl+C")
    slot = SLOTS.get(header[0].removeprefix("Item Class: "))
    if not slot or header[1] not in {"Rarity: Normal", "Rarity: Magic", "Rarity: Rare"}:
        raise ValueError("неподдерживаемый тип или редкость")
    if any("Unidentified" in line or "Unusable" in line or line.startswith("Socketed") for line in lines):
        raise ValueError("предмет не опознан, недоступен или содержит особые гнёзда")
    anchor = next((i for i, section in enumerate(sections) if any(re.fullmatch(r"Item Level: \d+", line) for line in section)), None)
    if anchor is None:
        raise ValueError("нет строки Item Level")
    required = 0
    requires = blank_stats()
    properties = {}
    for part in sections[1:anchor]:
        if part and part[0] == "Requirements:":
            for line in part[1:]:
                m = re.fullmatch(r"(Level|Str|Dex|Int)(?::)?\s+(\d+)(?:\s+\(augmented\))?", line)
                if not m:
                    raise ValueError(f"неизвестное требование {line}")
                if m[1] == "Level":
                    required = int(m[2])
                else:
                    requires[m[1].lower()] = int(m[2])
        else:
            for line in part:
                if ":" in line:
                    key, value = line.split(":", 1)
                    properties[key] = value.strip().removesuffix(" (augmented)")
    if any(key in properties for key in ("Elemental Damage", "Chaos Damage")):
        raise ValueError("талисман содержит другие типы урона")
    if "Sockets" in properties and re.search(r"[^S\s]", properties["Sockets"]):
        raise ValueError("содержимое гнёзд не поддерживается")
    grants = blank_stats()
    life = area = 0
    for line in (line for part in sections[anchor + 1:] for line in part):
        line = re.sub(r" \(implicit\)$", "", line)
        if line in SKIP_FLAGS:
            continue
        m = re.fullmatch(r"\+(\d+) to (Strength|Dexterity|Intelligence|all Attributes|maximum Life)", line)
        if m:
            value = int(m[1])
            if m[2] == "maximum Life":
                life += value
            elif m[2] == "all Attributes":
                for attr in grants:
                    grants[attr] += value
            else:
                grants[ATTRS[m[2]]] += value
            continue
        m = re.fullmatch(r"(\d+)% increased Area of Effect", line)
        if m:
            area += int(m[1])
            continue
        if slot == "talisman" and any(re.fullmatch(p, line) for p in LOCAL_WEAPON):
            # Physical Damage and APS are already the final local values in the tooltip.
            continue
        raise ValueError(f"эффект пока не рассчитывается: {line}")
    item = {
        "id": item_id, "name": " / ".join(header[2:]), "league": league, "slot": slot,
        "location": location, "confirmed": True, "required_level": required,
        "requires": requires, "grants": grants, "life": life, "increased_area": area,
    }
    if slot == "talisman":
        damage = re.fullmatch(r"(\d+)\s*[-–]\s*(\d+)", properties.get("Physical Damage", ""))
        speed = properties.get("Attacks per Second", "")
        if not damage or not re.fullmatch(r"\d+(?:\.\d+)?", speed):
            raise ValueError("нет проверяемой физической базы и скорости")
        item["physical_damage"] = [int(damage[1]), int(damage[2])]
        item["attacks_per_second"] = float(speed)
    return item


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--league", required=True)
    parser.add_argument("--level", required=True, type=int)
    parser.add_argument("--strength", required=True, type=int)
    parser.add_argument("--dexterity", required=True, type=int)
    parser.add_argument("--intelligence", required=True, type=int)
    parser.add_argument("--life", required=True, type=int)
    for label in ("stash", "inventory", "equipped"):
        parser.add_argument("--" + label, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    items = []
    used = set()
    for location in ("stash", "inventory", "equipped"):
        folder = getattr(args, location)
        if folder is None:
            continue
        if not folder.is_dir():
            parser.error(f"нет папки {folder}")
        for file in sorted(folder.glob("*.txt")):
            actual = file.resolve()
            if actual in used:
                parser.error(f"файл {file} указан повторно")
            used.add(actual)
            item_id = hashlib.sha256((location + ":" + file.name).encode("utf-8")).hexdigest()[:20]
            try:
                items.append(read_item(file.read_text(encoding="utf-8-sig"), item_id, args.league, location))
            except (ValueError, OSError) as exc:
                print(f"Пропущен {file.name}: {exc}", file=sys.stderr)
    if not items:
        parser.error("нет вещей с полностью поддерживаемыми эффектами")
    result = {
        "schema": 1, "league": args.league, "level": args.level, "base_life": args.life,
        "base_attributes": {"str": args.strength, "dex": args.dexterity, "int": args.intelligence}, "items": items,
    }
    with args.output.open("x", encoding="utf-8") as output:
        json.dump(result, output, ensure_ascii=False, indent=2)
        output.write("\n")
    print(f"Импортировано вещей: {len(items)}. {args.output}")


if __name__ == "__main__":
    try:
        main()
    except OSError as exc:
        sys.exit(str(exc))
