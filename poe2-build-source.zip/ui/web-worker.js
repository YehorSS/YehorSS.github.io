"use strict";

let engine;

async function startEngine() {
  const response = await fetch("poe2_build.wasm");
  if (!response.ok) throw new Error("Модуль расчёта недоступен. Перезагрузи страницу.");
  const { instance } = await WebAssembly.instantiate(await response.arrayBuffer());
  return instance.exports;
}

self.onmessage = async ({ data: request }) => {
  try {
    engine ??= startEngine().catch(error => { engine = undefined; throw error; });
    const wasm = await engine;
    const bytes = new TextEncoder().encode(JSON.stringify(request));
    const pointer = wasm.prepare_request(bytes.length);
    if (!pointer) throw new Error("Файл слишком большой для расчёта.");
    new Uint8Array(wasm.memory.buffer, pointer, bytes.length).set(bytes);
    wasm.process_request();
    const reply = new Uint8Array(wasm.memory.buffer, wasm.response_ptr(), wasm.response_len());
    self.postMessage({ ...JSON.parse(new TextDecoder().decode(reply)), id: request.id });
  } catch (e) {
    self.postMessage({ id: request.id, error: e.message });
  }
};
