"use strict";

const $ = id => document.getElementById(id);
const settings = $("settings");
const pending = new Map();
let worker;
const pages = ["gems", "gear", "tree", "account"];
const number = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 3 });
let id = 0;
let active = "gems";
let profile;
let gearInput;
let treeInput;
let treeDemo = false;
let chooseAscendancy = "";
let calculation = 0;
let classes = [];
let selectedCharacter;
const allStyles = Array.from(field("playstyle").options);

window.receiveBuildReply = message => {
  const request = pending.get(message.id);
  if (!request) return;
  pending.delete(message.id);
  if (message.error) request.reject(new Error(message.error));
  else request.resolve(message.result);
};

function send(action, params = {}, input = "") {
  return new Promise((resolve, reject) => {
    const request = ++id;
    pending.set(request, { resolve, reject });
    const payload = { id: request, action, params, input };
    try {
      if (window.ipc?.postMessage) window.ipc.postMessage(JSON.stringify(payload));
      else {
        if (!worker) {
          worker = new Worker("./web-worker.js");
          worker.onmessage = ({ data }) => window.receiveBuildReply(data);
          worker.onerror = () => {
            worker.terminate();
            worker = undefined;
            for (const call of pending.values()) call.reject(new Error("Модуль расчёта не запустился."));
            pending.clear();
          };
        }
        worker.postMessage(payload);
      }
    }
    catch (error) { pending.delete(request); reject(error); }
  });
}

function field(name) { return settings.elements.namedItem(name); }
function syncStyles(classProfile) {
  const select = field("playstyle");
  const previous = select.value;
  const options = classProfile ? allStyles.filter(option => classProfile.styles.includes(option.value)) : allStyles;
  select.replaceChildren(...options);
  select.value = options.some(option => option.value === previous) ? previous : (classProfile?.style ?? options[0].value);
}
function el(tag, value, cls) {
  const element = document.createElement(tag);
  if (value !== undefined) element.textContent = value;
  if (cls) element.className = cls;
  return element;
}
function link(text, source, cls = "text-button") {
  const button = el("button", text, cls);
  button.type = "button";
  button.dataset.link = source;
  return button;
}
function error(message) {
  $("error").hidden = !message;
  $("error").textContent = message || "";
}
function setText(id, value) { $(id).textContent = value; }

function switchPage(page) {
  active = page;
  error();
  for (const value of pages) $(value).hidden = value !== page;
  for (const nav of document.querySelectorAll("nav [data-tab]")) {
    if (nav.dataset.tab === page) nav.setAttribute("aria-current", "page");
    else nav.removeAttribute("aria-current");
  }
  $("calculate").hidden = page === "tree" || page === "account";
  $("calculate").firstChild.nodeValue = page === "gear" ? "Подобрать комплект " : "Рассчитать ";
  $("calculate").disabled = false;
  if (page === "gear" && gearInput !== undefined) calculateGear();
}
document.addEventListener("click", event => {
  const nav = event.target.closest("[data-tab]");
  const external = event.target.closest("[data-link]");
  if (nav) { event.preventDefault(); switchPage(nav.dataset.tab); }
  if (external) {
    const href = external.dataset.link;
    if (window.ipc?.postMessage) send("open", {}, href).catch(e => error(e.message));
    else {
      const url = new URL(href);
      if (url.protocol === "https:" && ["poe2db.tw", "mobalytics.gg", "github.com", "www.pathofexile.com"].includes(url.hostname)) {
        window.open(url.href, "_blank", "noopener,noreferrer");
      }
    }
  }
});

function adjust() {
  const minions = field("playstyle").value === "minion";
  const witch = (field("character").value === "witch" || field("character").value === "auto") &&
    ["", "Infernalist"].includes(field("ascendancy").value);
  $("minion-options").hidden = !minions;
  $("button-options").hidden = minions;
  $("beidat-option").hidden = !witch;
  field("beidat").disabled = !minions || !witch;
  $("life-option").hidden = field("goal").value !== "survival" && !(minions && witch && field("beidat").checked);
  field("life").required = minions && witch && field("beidat").checked;
}
function getParams() {
  const params = Object.fromEntries(new FormData(settings));
  const style = params.playstyle;
  params.style = ["bear", "wolf", "caster"].includes(style) ? style : "any";
  if (selectedCharacter) params["character-level"] = String(selectedCharacter.level);
  return params;
}
function phaseChange() {
  const end = field("phase").value === "endgame";
  const presets = { "gem-level": end ? 20 : 1, "skill-tier": end ? 20 : 1, "spirit-tier": end ? 20 : 1, "support-tier": end ? 5 : 1, sockets: end ? 5 : 2 };
  for (const [key, value] of Object.entries(presets)) field(key).value = value;
}
settings.addEventListener("change", event => {
  if (event.target.name === "phase") phaseChange();
  if (event.target.name === "playstyle") {
    if (!selectedCharacter && field("character").value === "auto") syncAscendancy([]);
  }
  if (event.target.name === "character") {
    if (selectedCharacter?.class !== field("character").value) clearCharacter();
    const item = classes.find(c => c.id === field("character").value);
    syncStyles(item);
    syncAscendancy(item?.ascendancies ?? []);
  }
  adjust();
  if (settings.checkValidity()) calculateGems();
});
settings.addEventListener("submit", event => {
  event.preventDefault();
  if (active === "gems") calculateGems();
  if (active === "gear") calculateGear();
});

function renderGems(result, params) {
  profile = result.profile;
  syncAscendancy(profile.ascendancies, params.ascendancy);
  const minions = params.playstyle === "minion";
  const title = $("hero-title");
  title.replaceChildren("Подбор", el("br"), minions ? "миньонов" : "камней");
  setText("hero-context", profile.class.toLocaleUpperCase("ru-RU") + " / " + (params.phase === "acts" ? "АКТЫ" : "ЭНДГЕЙМ"));
  setText("hero-description", minions ? "Резерв Духа, требования и выбор восхождения." : "Умения и поддержка под твой стиль игры.");
  $("hero").classList.toggle("hero-minion", minions);
  $("hero").dataset.class = profile.class_id;
  setText("results-title", minions ? "Резерв миньонов" : "Результат расчёта");
  setText("result-count", result.cards.length ? String(result.cards.length) : "");
  setText("snapshot-date", "· " + result.snapshot.split("-").reverse().join("."));
  $("notice").hidden = !result.notice;
  setText("notice", result.notice ?? "");
  const results = $("gem-results");
  results.replaceChildren(...result.cards.map(renderGem));
  if (!result.cards.length && !result.notice) results.append(el("p", "Для выбранного стиля и тира подходящих камней в каталоге нет.", "inline-note"));
  renderProfile(profile, params);
  adjust();
  populateScopes();
}
function renderGem(record) {
  const root = $("gem-template").content.firstElementChild.cloneNode(true);
  root.querySelector("h3").textContent = record.name;
  root.querySelector(".metric-label").textContent = record.label;
  root.querySelector(".metric").textContent = ({
    "×": "×" + number.format(record.value),
    "%": number.format(record.value) + "%",
    "DPS": number.format(record.value) + " DPS",
    "hp/s": number.format(record.value) + " HP/с",
  })[record.unit] ?? number.format(record.value);
  const supports = root.querySelector(".gem-supports");
  for (const support of record.supports) supports.append(link("+ " + support.name, support.source, "chip"));
  if (record.helper) {
    const button = link("2-я кнопка · " + record.helper.name, record.helper.source, "chip");
    button.title = record.helper.note;
    supports.append(button);
  }
  const stats = root.querySelector(".gem-stats");
  for (const [label, value] of record.stats) {
    const item = el("div");
    item.append(el("small", label), el("b", number.format(value)));
    stats.append(item);
  }
  root.querySelector(".formula").textContent = record.formula;
  root.querySelector(".gem-note").textContent = record.note;
  const links = root.querySelector(".gem-links");
  links.append(link("Камень на PoE2DB ↗", record.source));
  if (record.helper) links.append(el("span", record.helper.note));
  return root;
}
function renderProfile(person, params) {
  const dest = $("profile-results");
  dest.replaceChildren(el("div", person.class + (params.character === "auto" ? " · выбран по стилю" : ""), "profile-title"));
  const starter = el("div", undefined, "asc");
  starter.append(el("p", "Стартовое умение · тир " + person.starter.tier));
  starter.append(link(person.starter.name, person.starter.source));
  if (person.selected) starter.append(el("p", "Восхождение · " + person.selected));
  dest.append(starter);
  for (const pick of person.picks) {
    const section = el("article", undefined, "asc");
    section.append(el("h3", pick.name));
    if (pick.target) section.append(el("p", pick.target, "target"));
    section.append(el("p", pick.description));
    const actions = el("div", undefined, "actions");
    actions.append(link("Узлы ↗", pick.source));
    if (pick.target) {
      const path = el("button", "Проложить путь", "text-button");
      path.addEventListener("click", () => {
        chooseAscendancy = pick.name;
        populateScopes();
        $("tree-target").value = pick.target;
        switchPage("tree");
        if (treeInput !== undefined) loadTreeStarts();
      });
      actions.append(path);
    }
    section.append(actions);
    dest.append(section);
  }
  if (!person.picks.length) dest.append(el("div", person.ascendancies.join(" · "), "asc"));
  if (person.guide) {
    const guide = el("div", undefined, "profile-guide");
    guide.append(link(params.phase === "acts" ? "Дерево по актам ↗" : "Дерево на картах ↗", person.guide));
    dest.append(guide);
  }
}

async function calculateGems() {
  const ticket = ++calculation;
  const params = getParams();
  try {
    const result = await send("gems", params);
    if (ticket === calculation) renderGems(result, params);
    if (active === "gems" && ticket === calculation) error();
  } catch (e) { if (active === "gems" && ticket === calculation) error(e.message); }
}

async function readFile(input) {
  const file = input.files[0];
  if (!file) return;
  if (file.size > 10 * 1024 * 1024) throw new Error("Выбери JSON размером до 10 МБ.");
  const inputText = await file.text();
  if (!inputText.trim()) throw new Error("Выбранный файл пуст.");
  return { inputText, name: file.name };
}
$("gear-file").addEventListener("change", async event => {
  try {
    const file = await readFile(event.target);
    if (!file) return;
    gearInput = file.inputText;
    setText("gear-file-name", file.name);
    if (settings.reportValidity()) calculateGear();
  } catch (e) { error(e.message); }
});
$("gear-demo").addEventListener("click", () => {
  gearInput = "";
  $("gear-file").value = "";
  setText("gear-file-name", "Учебный набор");
  if (settings.reportValidity()) calculateGear();
});
let gearJob = 0;
async function calculateGear() {
  if (gearInput === undefined) { error("Выбери JSON с предметами или открой учебный пример."); return; }
  const ticket = ++gearJob;
  const button = $("calculate");
  button.disabled = true;
  try {
    const result = await send("gear", getParams(), gearInput);
    if (ticket !== gearJob) return;
    if (active === "gear") error();
    const dest = $("gear-results");
    const pane = el("article", undefined, "report");
    pane.append(el("h2", "Проверено комплектов: " + number.format(result.checked)),
      el("p", result.detail ?? "Нет комплекта с рассчитываемым результатом."));
    if (result.sequence.length) {
      const steps = el("ol");
      for (const row of result.sequence) {
        const step = el("li", row.name);
        step.append(el("small", row.location + " · " + row.id));
        steps.append(step);
      }
      pane.append(steps);
    }
    if (result.skipped.length) {
      const details = el("details");
      details.append(el("summary", "Пропущено предметов: " + result.skipped.length));
      const list = el("ul");
      for (const item of result.skipped) list.append(el("li", item));
      details.append(list);
      pane.append(details);
    }
    dest.replaceChildren(pane);
  } catch (e) { if (active === "gear" && ticket === gearJob) error(e.message); }
  finally { if (active === "gear" && ticket === gearJob) button.disabled = false; }
}

function populateScopes() {
  const select = $("tree-scope");
  if (treeDemo) { select.replaceChildren(new Option("Основное дерево", "")); return; }
  const names = [...(profile?.ascendancies ?? [])];
  if (chooseAscendancy && !names.includes(chooseAscendancy)) names.push(chooseAscendancy);
  select.replaceChildren(new Option("Основное дерево", ""), ...names.map(name => new Option(name, name)));
  select.value = chooseAscendancy;
}
$("tree-scope").addEventListener("change", () => {
  chooseAscendancy = $("tree-scope").value;
  if (treeInput !== undefined) loadTreeStarts();
});
$("tree-file").addEventListener("change", async event => {
  try {
    const file = await readFile(event.target);
    if (!file) return;
    treeDemo = false;
    treeInput = file.inputText;
    setText("tree-file-name", file.name);
    populateScopes();
    await loadTreeStarts();
  } catch (e) { error(e.message); }
});
$("tree-demo").addEventListener("click", async () => {
  $("tree-file").value = "";
  treeDemo = true;
  treeInput = "";
  $("tree-target").value = "3";
  $("tree-allocated").value = "";
  setText("tree-file-name", "Учебное дерево");
  populateScopes();
  await loadTreeStarts();
  if ($("tree-start").value) $("tree-fields").requestSubmit();
});
let treeJob = 0;
async function loadTreeStarts() {
  const ticket = ++treeJob;
  const starts = $("tree-start");
  const scope = $("tree-scope").value;
  starts.replaceChildren(new Option("Загрузка…", ""));
  try {
    const result = await send("tree", { ascendancy: scope, demo: treeDemo ? "1" : "0" }, treeInput);
    if (ticket !== treeJob) return;
    starts.replaceChildren(new Option("Выбери старт", ""), ...result.starts.map(row =>
      new Option((row.name || "Класс " + row.index) + " · " + row.id, row.id)));
    if (treeDemo || result.starts.length === 1) starts.value = result.starts[0]?.id || "";
    if (!result.starts.length) error("В этом экспорте нет стартового узла для выбранной ветки.");
    else error();
  } catch (e) { if (ticket === treeJob) error(e.message); }
}
$("tree-fields").addEventListener("submit", async event => {
  event.preventDefault();
  if (treeInput === undefined) { error("Сначала загрузи экспорт дерева."); return; }
  const ticket = ++treeJob;
  $("tree-route").disabled = true;
  try {
    const result = await send("tree", {
      ascendancy: $("tree-scope").value, start: $("tree-start").value,
      target: $("tree-target").value, points: $("tree-points").value,
      allocated: $("tree-allocated").value, demo: treeDemo ? "1" : "0",
    }, treeInput);
    if (ticket !== treeJob) return;
    error();
    const route = result.route;
    const panel = el("article", undefined, "report");
    panel.append(el("h2", route.target), el("p", "Нужно очков: " + route.steps.length + ". Свободно: " + route.points + "."));
    const list = el("ol");
    for (const step of route.steps) {
      const item = el("li", step.name + " · " + step.id, step.available ? "" : "later");
      item.append(el("small", (step.available ? "Можно взять сейчас" : "Нужно ещё очко") + (step.stats.length ? " · " + step.stats.join(" / ") : "")));
      list.append(item);
    }
    panel.append(list);
    $("tree-results").replaceChildren(panel);
  } catch (e) { if (ticket === treeJob) error(e.message); }
  finally { $("tree-route").disabled = false; }
});

function syncAscendancy(names, selected = "") {
  const input = field("ascendancy");
  input.replaceChildren(new Option("Подобрать по стилю", ""), ...names.map(name => new Option(name, name)));
  input.value = names.includes(selected) ? selected : "";
}

function clearCharacter() {
  if (!selectedCharacter) return;
  selectedCharacter = undefined;
  field("character-level").value = "";
  $("active-character").hidden = true;
}

function activateCharacter(character) {
  selectedCharacter = character;
  const current = classes.find(item => item.id === character.class);
  field("character").value = current.id;
  syncStyles(current);
  field("character-level").value = character.level;
  syncAscendancy(current.ascendancies, character.ascendancy);
  chooseAscendancy = character.ascendancy || "";
  setText("active-character", character.name + " · ур. " + character.level);
  $("active-character").hidden = false;
  adjust();
  switchPage("gems");
  calculateGems();
}
async function loadCharacters(input) {
  const result = await send("characters", {}, input);
  const container = $("character-results");
  const panel = el("article", undefined, "report");
  panel.append(el("h2", "Персонажи · " + result.characters.length));
  for (const character of result.characters) {
    const row = el("section", undefined, "character-row");
    const text = el("div");
    text.append(el("h3", character.name), el("small", [
      character.class_name, character.ascendancy, "ур. " + character.level, character.league,
    ].filter(Boolean).join(" · ")));
    if (character.passives.length || character.equipment || character.skills) {
      text.append(el("small", "Пассивки: " + character.passives.length + " · Экипировка: " + character.equipment + " · Умения: " + character.skills));
    }
    const button = el("button", "Выбрать", "secondary");
    button.addEventListener("click", () => activateCharacter(character));
    row.append(text, button);
    panel.append(row);
  }
  if (result.skipped) panel.append(el("small", "Пропущено записей: " + result.skipped));
  if (!result.characters.length) panel.append(el("p", "В файле нет доступных персонажей PoE 2."));
  container.replaceChildren(panel);
}
$("character-file").addEventListener("change", async event => {
  try {
    const file = await readFile(event.target);
    if (!file) return;
    await loadCharacters(file.inputText);
    setText("character-file-name", file.name);
    error();
  } catch (e) { error(e.message); }
});
$("character-demo").addEventListener("click", async () => {
  try {
    await loadCharacters(JSON.stringify({ characters: [
      {name:"Пример · Рейнджер",class:"Deadeye",level:42,league:"Demo"},
      {name:"Пример · Ведьма",class:"Infernalist",level:90,league:"Demo"},
    ] }));
    setText("character-file-name", "Учебный список");
    error();
  } catch (e) { error(e.message); }
});

async function initialize() {
  try {
    classes = (await send("classes")).classes;
    field("character").append(...classes.map(item => new Option(item.name, item.id)));
    adjust();
    await calculateGems();
  } catch (e) { error(e.message); }
}
initialize();

